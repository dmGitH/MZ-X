/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package audio_rec;

/**
 *
 * @author dm
 */
public class LanguageClass {

    public String s(String l, int szo) {

        String valasz = "";

        if ("hu".equals(l)) {
            switch (szo) {
                case 1:
                    return "A kiválasztott fájl törlése";
                case 2:
                    return "Lista frissítése";
                case 3:
                    return "A kijelző törlése";
                case 4:
                    return "Vágólapra másol";
                case 5:
                    return "A kulcsfájl mérete nem lehet kisebb  5 MB-nál, válasszon másik kulcsot.";
                case 6:
                    return "Hiba! ";
                case 7:
                    return "Figyelem! ";
                case 8:
                    return "Info: ";
                case 9:
                    return "Még nem történt meg a kapcsolatfelvétel. Kérem regisztrálja magát egy Semotus szerveren.";
                case 10:
                    return "A hangüzenet rögzítése megkezdődött";
                case 11:
                    return "Kapcsolódás";
                case 12:
                    return "Kikapcsolás";
                case 13:
                    return " A regisztráció törlése során hiba történt ";
                case 14:
                    return "A szerver és a célport a kapcsolódó felek között fordított legyen.";
                case 15:
                    return " fájlt nem sikerült megnyitni";
                case 16:
                    return "A megadott becenév túl rövid";
                case 17:
                    return " A regisztráció során hiba történt ";
                case 18:
                    return "A regisztráció frissítése megtörtént";
                case 19:
                    return "Az új regisztráció megtörtént";
                case 20:
                    return "A hiba a szervernél jelentkezett";
                case 21:
                    return "Az aktuális regisztráció törlésre került";
                case 22:
                    return "Ilyen paraméterekkel nincs regisztráció";
                case 23:
                    return "Hiba, a weboldal megnyitása megszakítva.";
                case 24:
                    return "A működéshez nincsenek jól beállítva a paraméterek.";
                case 25:
                    return "Folyamatban";
                case 26:
                    return "Felvétel indul";
                case 27:
                    return "Felvétel sikerült";
                case 28:
                    return "A hangüzenet rögzítése befejeződött";
                case 29:
                    return "A hangüzenet felvétele nem sikerült";
                case 30:
                    return "Adás indul";
                case 31:
                    return "Minden OK";
                case 32:
                    return "Hiba a küldés folyamatában";
                case 33:
                    return "A kódolás sikertelen";
                case 34:
                    return " A regisztráltak keresése közben";
                case 35:
                    return "Hiba a keresési folyamatban ";
                case 36:
                    return "Hibás szerverválasz ";
                case 37:
                    return " A szerverválasz dekódolása közben";
                case 38:
                    return "Portszám: ";
                case 39:
                    return "A Figyelő szál leállítása kezdeményezve";
                case 40:
                    return "A Figyelő szál nem élt";
                case 41:
                    return "Az életjel szál leállítása kezdeményezve";
                case 42:
                    return "A regisztrációs szál nem élt";
                case 43:
                    return "A fájl fogadó szerver leállítása kezdeményezve";
                case 44:
                    return "A fájl fogadást figyelő szál nem élt";
                case 45:
                    return "Azonosítónév";
                case 46:
                    return "Hívójeled, amit csak az azonos szerveren, és azonos kulcsal regisztárlat látnak";
                case 47:
                    return "Kapcsolat beállítása";
                case 48:
                    return "A szerver címének és a OneTimePad kulcsnak a beállítása";
                case 49:
                    return "Kapcsolódás";
                case 50:
                    return "Kapcsolódás a megadott paraméterekkel";
                case 51:
                    return "Piros: nincs kapcsolat, zöld: kapcsolódva";
                case 52:
                    return "Szerver port aktív";
                case 53:
                    return "Ugyanazon a szerveren, ugyanazon kulcsal regisztrált kliensek";
                case 54:
                    return "Regisztráció aktív";
                case 55:
                    return "Szerverport";
                case 56:
                    return "Küldőport";
                case 57:
                    return "Művelet:";
                case 58:
                    return "ADÁS";
                case 59:
                    return "Hangfelvétel rögzítése, küldése";
                case 60:
                    return "VÉTEL";
                case 61:
                    return "A hangfelvétel megszakítása. (Vétel)";
                case 62:
                    return "Rendszerhang ki vagy bekapcsolása, változtatása";
                case 63:
                    return "Rendszer hang";
                case 64:
                    return "Rendszer ikonok közé, kicsinyítés";
                case 65:
                    return "Küldött: 0 Kb";
                case 66:
                    return "Fogadott: 0 Kb";
                case 67:
                    return "Fájl fogadás engedélyezése";
                case 68:
                    return "Fájlküldés";
                case 69:
                    return "Szöveges üzenetküldés";
                case 70:
                    return "Szigorúan OneTimePad";
                case 71:
                    return "Ez a kommunikációs végpont küldőportja";
                case 72:
                    return "Ez a kommunikációs végpont fogadóportja";
                case 73:
                    return "Portcsere";
                case 74:
                    return "Törlés-Bezár";
                case 75:
                    return "Küldés-Enter";
                case 76:
                    return "Kulcs fájl nyitás hiba";
                case 77:
                    return "Kulcs fájl zárási hiba: ";
                case 78:
                    return "Az üzenet kódolásakor hiba történt";
                case 79:
                    return "Hiba az üzenet küldésekor 2310 : ";
                case 80:
                    return "kulcs eleje: ";
                case 81:
                    return "Hiba a kulcsfájl pozicionálásakor ";
                case 82:
                    return "Hiba az üzenet küldésekor ";
                case 83:
                    return "Küldve";
                case 84:
                    return "Fogadva";
                case 85:
                    return " Hiba a kulcsfájl olvasásakor. ";
                case 86:
                    return "Add meg a semotus server címét";
                case 87:
                    return "Mégsem";
                case 88:
                    return "Utasítás";
                case 89:
                    return "Válaszd ki a kulcsfájlt";
                case 90:
                    return "Válaszd ki a küldendő fájlt";
                case 91:
                    return "Válaszd ki a fájlt";
                case 92:
                    return "Válassz mappát";
                case 93:
                    return "Küldendő fájl: ";
                case 94:
                    return "Az adott cím vagy helytelen vagy nem elérhető";
                case 95:
                    return "Nem adott meg címet vagy helytelen a formátuma";
                case 96:
                    return "A megadott url Semotus webalkalmazás";
                case 97:
                    return "Sikeres ellenőrzés";
                case 98:
                    return "A megadott url átirányított oldal, próbálja meg más formátumban beírni. (https,www.)";
                case 99:
                    return "A megadott url nem Semotus webapplication";
                case 100:
                    return "újport: ";
                case 101:
                    return "Nincsen szabad port az adatfogadáshoz. A fogadó fél megszakította a kapcsolatot.";
                case 102:
                    return "Az adatküldés indulhat";
                case 103:
                    return "Küldött fájl mérete: ";
                case 104:
                    return "Forrásfájlnyitás hiba";
                case 105:
                    return "Forrás fájl nyitás: ";
                case 106:
                    return "Forrás fájl nyitás után, elérhető hossza: ";
                case 107:
                    return " fálj megnyitási hiba.";
                case 108:
                    return " A Kimenet megnyitva ";
                case 109:
                    return "A cél nem fogadja az üzeneteket";
                case 110:
                    return "Hiba a küldési folyamatban";
                case 111:
                    return "A végpontválasza nem OK";
                case 112:
                    return "Küldött: ";
                case 113:
                    return "Fő szerver indítása -----------";
                case 114:
                    return "A Serverszál leállt...\nVárja meg amíg a regisztrációs szál is leáll.";
                case 115:
                    return "Server szál leállt\nVárja meg amíg a regisztrációs szál is leáll.\nUtánna kezdeményezhet új kapcsolatot\n";
                case 116:
                    return "Üzenetfogadás indítva: ";
                case 117:
                    return "A port nem elérhető: ";
                case 118:
                    return "Szerver művelet...";
                case 119:
                    return "Server socket megnyitva";
                case 120:
                    return "Server socket megnyitási hiba";
                case 121:
                    return "Server socket lezárási hiba 2";
                case 122:
                    return "Kimenet nyitás hiba";
                case 123:
                    return "Bemenet nyitás hiba.";
                case 124:
                    return "Üzenet olvasási hiba ";
                case 125:
                    return "Localhost --- server-stop";
                case 126:
                    return "Hangátvitel kiszolgálás indul >> ";
                case 127:
                    return "Szöveg átvitel, kiszolgálás ";
                case 128:
                    return "Szöveges üzenet fogadási hiba ";
                case 129:
                    return "fogadott : ";
                case 130:
                    return "fogadott mérete: ";
                case 131:
                    return "Adat fogadásakor. Buffer olvasási hiba ";
                case 132:
                    return "Fogadott: ";
                case 133:
                    return "Adatra várt: ";
                case 134:
                    return "Új üzeneted jött. ";
                case 135:
                    return " A Kimenet megnyitva ";
                case 136:
                    return " Kimenet megnyitási hiba. ";
                case 137:
                    return "Kulcs eleje: ";
                case 138:
                    return " A Kulcsfájl megnyitva ";
                case 139:
                    return "Hiba a kulcsfájl megnyitásakor.";
                case 140:
                    return "Hiba a kulcsfájl pozícionálásakor ";
                case 141:
                    return " A Forrásfájl megnyitva ";
                case 142:
                    return " fájl megnyitási hiba.";
                case 143:
                    return " fájlhossz kiolvasasi hiba.";
                case 144:
                    return " kimenet megnyitási hiba.";
                case 145:
                    return "Művelet: fájl kódolása: ";
                case 146:
                    return " A fájl kódolása végetért : ";
                case 147:
                    return "Forrás fájl lezárva. ";
                case 148:
                    return "Hiba a kodolandó fájl lezárásakor.";
                case 149:
                    return "Cél fájl lezárva. ";
                case 150:
                    return " Hiba a kódolt fájl lezárásakor.";
                case 151:
                    return "Fájl kódolása befejeződött";
                case 152:
                    return "Fájl elküldve...";
                case 153:
                    return "Hiba a küldés folyamatában";
                case 154:
                    return "Fogadott fájl kódolása befejeződött";
                case 155:
                    return "Kulcs fájl lezárva. ";
                case 156:
                    return "Hiba kulcs fájl lezárásakor. ";
                case 157:
                    return " Hiba a kulcsfájl olvasásakor. ";
                case 158:
                    return " Hiba a forrásfájl olvasásakor. ";
                case 159:
                    return " Hiba a kódolt fájlba íráskor ";
                case 160:
                    return "Kisegitő-fájlszerver indítása-----------PORT: ";
                case 161:
                    return "Kisegitő-fájlserver leállt...";
                case 162:
                    return "Kisegitő szerver port: ";
                case 163:
                    return "A port nem elérhető: ";
                case 164:
                    return "Kisegitő-fájlszerver művelet...Port: ";
                case 165:
                    return "Fájl Server socket megnyitva. Port: ";
                case 166:
                    return "Fájl Server socket megnyitási hiba. Port: ";
                case 167:
                    return "Fájl Server socket lezárási hiba.";
                case 168:
                    return "Vezérlési info olvasási hiba";
                case 169:
                    return "Fájlátvitel kiszolgálása indul ---- kisegitő szerver port: ";
                case 170:
                    return "Buffer olvasási hiba";
                case 171:
                    return "Rögzitett hang fájlba írási hiba ";
                case 172:
                    return "A regisztrációs szál leállt...";
                case 173:
                    return "Életjelszál leállt....";
                case 174:
                    return "\"életjel...\"";
                case 175:
                    return "A regisztrációs szerverrel történő kommunikáció közben.";
                case 176:
                    return "Az elérhető kapcsolatok számában változás történt";
                case 177:
                    return "A Fájl Serverszál leállt...";
                case 178:
                    return "Fájl zerver szál indítása -----------";
                case 179:
                    return "Szerver szál leállt";
                case 180:
                    return "Fájlfogadó szerver indítva: ";
                case 181:
                    return "MZ/X-JAVA(Semotus.hu)";
                case 182:
                    return "Az alkalmazás a tálcaikonoknál elérhető.";
                case 183:
                    return "Webcím megnyitása";
                case 184:
                    return "Megjelenítés";
                case 185:
                    return "Semotus \"adóvevő\"";
                case 186:
                    return "Nem támogatott a tálca ikon";
                case 187:
                    return "Hiba a megadott webcímobjektum létrehozásakor\n A weboldal megnyitása megszakítva.";
                case 188:
                    return "Küldő socket megnyitva";
                case 189:
                    return "A megadott címen a küldő socket megnyitása sikertelen: (Tűzfalszabály?) ";
                case 190:
                    return "Kimeneti stream megnyitva";
                case 191:
                    return "Bejövő stream megnyitva";
                case 192:
                    return "A szöveges adat fogadása visszautasítva a fogadó oldalon";
                default:
                    break;
            }

        } else if ("en".equals(l)) {
            switch (szo) {
                case 1:
                    return "Delete the selected file";
                case 2:
                    return "Updating list";
                case 3:
                    return "Clear the display";
                case 4:
                    return "Copy to clipboard";
                case 5:
                    return "The size of the key file should not be less than 5 MB, choose another key.";
                case 6:
                    return "Error! ";
                case 7:
                    return "Warning! ";
                case 8:
                    return "Info: ";
                case 9:
                    return "No contact has been made yet. Please register on a Semotus server.";
                case 10:
                    return "Recording voice message started.";
                case 11:
                    return "Connect";
                case 12:
                    return "Turning off";
                case 13:
                    return "Error deleting registration";
                case 14:
                    return "The server and destination port should be reversed between related parties.";
                case 15:
                    return " file could not be opened";
                case 16:
                    return "The given nickname is too short";
                case 17:
                    return " Error during registration ";
                case 18:
                    return "Registration has been updated";
                case 19:
                    return "New registration has been completed";
                case 20:
                    return "Error encountered on server";
                case 21:
                    return "The current registration has been deleted";
                case 22:
                    return "No registration with such parameters";
                case 23:
                    return "Error opening web page.";
                case 24:
                    return "Parameters are not set correctly for operation.";
                case 25:
                    return "In progress";
                case 26:
                    return "Start recording";
                case 27:
                    return "Recording succeeded";
                case 28:
                    return "Recording of voice message completed";
                case 29:
                    return "Failed to record voice message";
                case 30:
                    return "Record Starts";
                case 31:
                    return "Everything is OK";
                case 32:
                    return "Error sending process";
                case 33:
                    return "Encoding failed";
                case 34:
                    return "Searching for Registered";
                case 35:
                    return "Error in search process ";
                case 36:
                    return "Incorrect server response ";
                case 37:
                    return "Decoding server response";
                case 38:
                    return "Port number: ";
                case 39:
                    return "server thread shutdown initiated...";
                case 40:
                    return "The server thread did not live.";
                case 41:
                    return "Stop registration thread";
                case 42:
                    return "The registration thread did not live";
                case 43:
                    return "Initiating file receiving server stop";
                case 44:
                    return "The file receiving thread did not live";
                case 45:
                    return "Code name";
                case 46:
                    return "Your code name is public to your peers";
                case 47:
                    return "Set up connection";
                case 48:
                    return "Set server address and set your OneTimePad key";
                case 49:
                    return "Connect";
                case 50:
                    return "Connect to server according to settings";
                case 51:
                    return "Red: No Connect, Green: Connected";
                case 52:
                    return "Server Port Active";
                case 53:
                    return "Clients registered with the same parameters on the same server";
                case 54:
                    return "Registration active";
                case 55:
                    return "Server Port";
                case 56:
                    return "Sender Port";
                case 57:
                    return "Operation:";
                case 58:
                    return "Broadcast";
                case 59:
                    return "Recording and sending audio recording";
                case 60:
                    return "STOP";
                case 61:
                    return "Interrupting audio recording. (Reception)";
                case 62:
                    return "Turn System volume On or Off";
                case 63:
                    return "System sound";
                case 64:
                    return "To System Tray";
                case 65:
                    return "Sent: 0 Kb";
                case 66:
                    return "Received: 0 Kb";
                case 67:
                    return "Allow file reception";
                case 68:
                    return "Send File";
                case 69:
                    return "Text messaging";
                case 70:
                    return "Only OneTimePad";
                case 71:
                    return "This is the port for sending the endpoint of communication";
                case 72:
                    return "This is the destination port for the communication endpoint";
                case 73:
                    return "Port Exchange";
                case 74:
                    return "Clear-Close";
                case 75:
                    return "Send-Enter";
                case 76:
                    return "Key File Opening Error";
                case 77:
                    return "Key file closing error:";
                case 78:
                    return "An error occurred while encoding the message";
                case 79:
                    return "Error sending message 2310:";
                case 80:
                    return "key start:";
                case 81:
                    return "Position error into key file";
                case 82:
                    return "Error sending message";
                case 83:
                    return "Sent";
                case 84:
                    return "Received";
                case 85:
                    return " Error reading key file. ";
                case 86:
                    return " Enter the semotus server address ";
                case 87:
                    return "Cancel";
                case 88:
                    return "Instructions";
                case 89:
                    return "Choose the key file";
                case 90:
                    return "Select the file to send";
                case 91:
                    return "Choose file";
                case 92:
                    return "Choose folder";
                case 93:
                    return "File to send: ";
                case 94:
                    return "The address is incorrect or unavailable";
                case 95:
                    return "Failed to enter address or incorrect format";
                case 96:
                    return "The specified url Semotus web application";
                case 97:
                    return "Successful check";
                case 98:
                    return "The specified url redirect page, try typing it in a different format (https, www.)";
                case 99:
                    return "The specified url is not Semotus web application";
                case 100:
                    return "newport: ";
                case 101:
                    return "There is no free port for receiving data. The host party interrupted the connection.";
                case 102:
                    return "Send data can start";
                case 103:
                    return "Sent file size: ";
                case 104:
                    return "Source File Open Error";
                case 105:
                    return "Source File Opening: ";
                case 106:
                    return "Source file after opening, available length: ";
                case 107:
                    return "File opening error.";
                case 108:
                    return "Opened";
                case 109:
                    return "Endpoint does not accept messages";
                case 110:
                    return "Error in sending process";
                case 111:
                    return "The endpoint response is not OK";
                case 112:
                    return "Sent: ";
                case 113:
                    return "Starting main server -----------";
                case 114:
                    return "The server thread has stopped ...\n Wait for the registration thread to stop. ";
                case 115:
                    return "Server thread stopped. Wait for registration thread to stop. Then initiate a new connection. ";
                case 116:
                    return "I accept the message ";
                case 117:
                    return "Port not available: ";
                case 118:
                    return "Server operation ...";
                case 119:
                    return "Server socket open ";
                case 120:
                    return "Server socket opening error ";
                case 121:
                    return "Server socket lockout error 2 ";
                case 122:
                    return "Output Open Error";
                case 123:
                    return "Input opening error.";
                case 124:
                    return "Message Read Error";
                case 125:
                    return "Localhost --- server-stop";
                case 126:
                    return "Voice Transfer Service Starts >>";
                case 127:
                    return "Text Transmission Service";
                case 128:
                    return "Text message reception error";
                case 129:
                    return "received: ";
                case 130:
                    return "received size: ";
                case 131:
                    return "Receiving data. Buffer reading error";
                case 132:
                    return "Received: ";
                case 133:
                    return "Waiting for data: ";
                case 134:
                    return "Your new message has come.";
                case 135:
                    return "Open Out";
                case 136:
                    return "Output opening error.";
                case 137:
                    return "Key start: ";
                case 138:
                    return " Key File Opened ";
                case 139:
                    return "Error opening key file. + ------------ +";
                case 140:
                    return "Error setuping for key file position";
                case 141:
                    return "Source file Opened";
                case 142:
                    return "file opening error.";
                case 143:
                    return "file length read error.";
                case 144:
                    return "output opening error.";
                case 145:
                    return "Action: File Encoding: ";
                case 146:
                    return "File encoding finished: ";
                case 147:
                    return "Source file closed. ";
                case 148:
                    return "Error closing file.";
                case 149:
                    return "Target file closed.";
                case 150:
                    return "Error Closing Encrypted File.";
                case 151:
                    return "File Encoding Complete";
                case 152:
                    return "File sent ...";
                case 153:
                    return "Error sending process";
                case 154:
                    return "Received file decoding complete";
                case 155:
                    return "Key file closed.";
                case 156:
                    return "Error when closing key file.";
                case 157:
                    return "Error reading key file. ";
                case 158:
                    return " Error reading source file. ";
                case 159:
                    return " Error writing to encrypted file ";
                case 160:
                    return "Starting an auxiliary file server ----------- PORT: ";
                case 161:
                    return "Auxiliary file server has stopped ... ";
                case 162:
                    return "Auxiliary server port: ";
                case 163:
                    return "Port not available: ";
                case 164:
                    return "Auxiliary File Server Operation ... Port: ";
                case 165:
                    return "File Server socket open. Port: ";
                case 166:
                    return "File Server socket opening error. Port: ";
                case 167:
                    return "Failed File Server Socket into close.";
                case 168:
                    return "Control info read error";
                case 169:
                    return "Sending File Starts ----  auxiliary in server port: ";
                case 170:
                    return "Buffer reading error";
                case 171:
                    return "Recorded audio file write error";
                case 172:
                    return "The registration thread has stopped ...";
                case 173:
                    return "Stoped Registration processe....";
                case 174:
                    return "Sign of life ... ";
                case 175:
                    return "During communication with the registration server.";
                case 176:
                    return "The number of available connections has changed";
                case 177:
                    return "Side File Server Stopped ...";
                case 178:
                    return "Start file server thread -----------";
                case 179:
                    return "Server thread stopped";
                case 180:
                    return "File receive server started: ";
                case 181:
                    return "MZ/X-JAVA(Semotus.hu)";
                case 182:
                    return "The application is available for tray icons.";
                case 183:
                    return "Open Web Address";
                case 184:
                    return "Show";
                case 185:
                    return "Semotus \"Transceiver\"";
                case 186:
                    return "Tray Icon Not Supported";
                case 187:
                    return "Error creating the specified web address object.\n Opening the web page is interrupted.";
                case 188:
                    return "Sending Socket Open";
                case 189:
                    return "Unable to open sender socket at specified address: (Firewall Rule?) ";
                case 190:
                    return "Output stream open";
                case 191:
                    return "Inbound stream opened";
                case 192:
                    return "Receiving text data is rejected on the receiving page";
                default:
                    break;
            }

        }

        return valasz;
    }

}
