/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package audio_rec;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dm
 */
public class AdataKuldese {

    Socket kuldoSocket = null;
    DataOutputStream out = null;
    DataInputStream kodoltfile = null;
    DataInputStream in = null;
    String SendFile;
    String SendFileName;
    TrayIconDemo tray;
    long kezdokulcs;
    FoForm obj;
    static String L = "hu";
    LanguageClass l = new LanguageClass();

    public AdataKuldese(String SendFile, String SendFileName, TrayIconDemo tray, long kezdokulcs, FoForm obj) {
        this.SendFile = SendFile;
        this.SendFileName = SendFileName;
        this.tray = tray;
        this.kezdokulcs = kezdokulcs;
        this.obj = obj;
    }

    public void feliratokbeallitasa() {

    }

    public boolean felvetelkuldese(String ip, int celport, int miert) {
        L=FoForm.getL();
        System.out.println("port: " + celport);
        System.out.println("IP: " + ip);
        File sendfile = new File(SendFile);
        File filemerete = new File(SendFileName);
        System.out.println("File: " + sendfile.getName());

        if (kuldoszalnyit(ip, celport)); else {
            return false;
        }

        try {
            out.writeByte(3);
        } catch (IOException ex) {

            System.out.println(ex);
            return false;
        }
        int ujport = 0;

        try {
            ujport = in.readInt();
            System.out.println(l.s(L,100) + ujport);
        } catch (IOException ex) {
            Logger.getLogger(AdataKuldese.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (celport != ujport) {
            kuldolezar();
            if (ujport == 0) {
                System.out.println(l.s(L,101));
                return false;
            }
            if (kuldoszalnyit(ip, ujport)); else {
                return false;
            }
            try {
                out.writeByte(3);
            } catch (IOException ex) {
                Logger.getLogger(AdataKuldese.class.getName()).log(Level.SEVERE, null, ex);
                return false;
            }
        } else ;

        byte kuldokapja;
        try {
            kuldokapja = in.readByte();

        } catch (IOException ex) {

            System.out.println(ex);
            return false;
        }
        if (kuldokapja == 10) {
            System.out.println(l.s(L,102));
            if (fajlnyitas()); else {
                return false;
            }
            long fajlmeret = filemerete.length();

            try {
                out.writeLong(kezdokulcs);
            } catch (IOException ex) {
                Logger.getLogger(FoForm.class.getName()).log(Level.SEVERE, null, ex);
            }

            System.out.println(l.s(L,103) + fajlmeret);
            int darabban;
            int buffmeret3 = 2048;

            buffmeret3 = Integer.parseInt((String) obj.jComboBox4.getSelectedItem());
            System.out.println("buff: " + buffmeret3);
            try {
                out.writeInt(buffmeret3);
            } catch (IOException ex) {
                Logger.getLogger(FoForm.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println(ex);
            }

            System.out.println(l.s(L,103)+ fajlmeret);
            try {
                out.writeLong(fajlmeret); //fájlméret
            } catch (IOException ex) {
                System.out.println(ex);
            }
            try {
                out.writeUTF(sendfile.getName());//filename
            } catch (IOException ex) {
                System.out.println(ex);
            }
            try {
                out.flush();
            } catch (IOException ex) {
                System.out.println(ex);
            }
            //buff,darab,fajlmeret
            kodoltfile = null;
            if (fajlnyitas()); else {
                System.out.println(l.s(L,104));
                return false;
            }
            System.out.println(l.s(L,105) + SendFile);
            try {
                System.out.println(l.s(L,106) + kodoltfile.available());
            } catch (IOException ex) {
                Logger.getLogger(FoForm.class.getName()).log(Level.SEVERE, null, ex);
            }
            byte[] data = new byte[buffmeret3];
            try {
                while (kodoltfile.available() > buffmeret3) {
                    try {
                        kodoltfile.read(data);
                    } catch (IOException ex) {
                        System.out.println(ex);
                    }
                    try {
                        out.write(data);
                    } catch (IOException ex) {
                        System.out.println(ex);
                    }
                    try {
                        out.flush();
                    } catch (IOException ex) {
                        System.out.println(ex);
                    }
//                    long tart = kodoltfile.available();
//                    int pbtart = obj.jProgressBar2.getValue();
                    obj.kuldott += buffmeret3;
                    final ScheduledExecutorService executorService2 = Executors.newSingleThreadScheduledExecutor();
                    executorService2.scheduleAtFixedRate(() -> {
//                        if ((int) ((tart * 100.0f) / fajlmeret) > pbtart); else {
//                            obj.jProgressBar2.setValue((int) ((tart * 100.0f) / fajlmeret));
//
//                            obj.jLabel13.setText("Művelet: fájl átvitel: " + ((int) ((tart * 100.0f) / fajlmeret)) + "%");
//                        }
                        obj.jLabel15.setText("Küldött: " + String.valueOf((obj.kuldott) / 1024 / 1024) + " MB");
                        executorService2.shutdown();
                    }, 0, 1, TimeUnit.SECONDS);
//                    System.out.println(" tart: " + tart);
                }
            } catch (IOException ex) {
                Logger.getLogger(FoForm.class.getName()).log(Level.SEVERE, null, ex);
            }
            int ujbuffmeret = 0;
            try {
                ujbuffmeret = kodoltfile.available();
            } catch (IOException ex) {
                Logger.getLogger(FoForm.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println("new buffer lenght: " + ujbuffmeret);
            obj.kuldott += buffmeret3;
            if (ujbuffmeret > 0) {
                data = new byte[ujbuffmeret];
                try {
                    kodoltfile.read(data);
                } catch (IOException ex) {
                    System.out.println(ex);
                }
                try {
                    out.write(data);
                } catch (IOException ex) {
                    System.out.println(ex);
                }

                try {
                    out.flush();
                } catch (IOException ex) {
                    System.out.println(ex);
                }
            }
            try {

                kodoltfile.close();
                kodoltfile = null;
                try {
                    try (DataOutputStream hozzair = new DataOutputStream(new FileOutputStream(SendFile, true))) {
                        hozzair.writeLong(kezdokulcs);
                    }
                } catch (FileNotFoundException ex) {
                    System.out.println(SendFile + l.s(L,107) + ex);

                }

            } catch (IOException ex) {
                System.out.println(ex);
            }
            String lezarva = "";
            try {
                lezarva = in.readUTF();
            } catch (IOException ex) {
                System.out.println(ex);
            }

            if ("OK".equals(lezarva)) {
                System.out.println("--OK--");
                kuldolezar();
            } else {
                System.out.println(l.s(L,110));
                kuldolezar();
                return false;
            }

        } else {
            tray.uzenetek_alert(obj, tray.getTrayIcon(), l.s(L,7), l.s(L,109), 1);
            return false;
        }

        return true;
    }

    public void kuldolezar() {

        try {
            in.close();
        } catch (IOException ex) {
            System.out.println(ex);
        }
        try {
            out.close();
        } catch (IOException ex) {
            System.out.println(ex);
        }
        try {
            kuldoSocket.close();
        } catch (IOException ex) {
            System.out.println(ex);
        }
        in = null;
        out = null;
        kuldoSocket = null;
    }

    public boolean fajlnyitas() {
        try {
            kodoltfile = new DataInputStream(new FileInputStream(SendFile));
            tray.uzenetek(obj, tray.getTrayIcon(), l.s(L,8), l.s(L,108) + SendFile, 0);
        } catch (FileNotFoundException ex) {
            System.out.println(SendFile + l.s(L,107) + ex);
            return false;

        }
        return true;
    }

    private boolean kuldoszalnyit(String ip, int celport) {
        try {
            kuldoSocket = new Socket(ip, celport);
        } catch (IOException ex) {

            tray.uzenetek_alert(obj, tray.getTrayIcon(), l.s(L,6), ex.toString(), 0);
            return false;
        }

        try {
            out = new DataOutputStream(kuldoSocket.getOutputStream());
        } catch (IOException ex) {

            tray.uzenetek_alert(obj, tray.getTrayIcon(), l.s(L,6), ex.toString(), 0);
            return false;
        }
        try {
            in = new DataInputStream(kuldoSocket.getInputStream());
        } catch (IOException ex) {

            tray.uzenetek_alert(obj, tray.getTrayIcon(), l.s(L,6), ex.toString(), 0);
            return false;
        }
        return true;
    }

}
