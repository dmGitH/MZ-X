/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package audio_rec;

import java.io.File;

/**
 *
 * @author dm
 */
public class OriginDeleteSec implements Runnable{

    File torolni;

    public OriginDeleteSec(File torolni) {
        this.torolni = torolni;
    }
    
    
    @Override
    public void run() {
       
        try {
            System.gc();
            Thread.sleep(2000);
            torolni.delete();
             System.out.println("audio_rec.OriginDeleteSec.run()");
        } catch (InterruptedException ex) {
            System.out.println(ex);
        }
    }
    
}
