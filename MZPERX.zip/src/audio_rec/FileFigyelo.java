/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package audio_rec;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dm
 */
public class FileFigyelo implements Runnable {

    int SERVERPORT;
    private final FoForm FoFormObj;
    ServerSocket serverSocket = null;
    boolean fut = true;
    boolean indul = true;
    TrayIconDemo tray;
    Socket clientSocket = null;
    DataOutputStream kout;
    DataInputStream kin;
    DataOutputStream save;
    String keyfile;
    DataInputStream key;
    Socket s;
    DataInputStream in;
    DataOutputStream out;

    Thread[] kiszolgalok = new Thread[10];
    int segedszerver = 0;

    String inputLine = null;

    String beolvas = null;
    int buffmeret = 40000;
    byte[] buff;
    long adatcrc = 0;

    static String L = "hu";
    LanguageClass l = new LanguageClass();

    public FileFigyelo(FoForm FoFormObj, TrayIconDemo tray, int szerverport) {
        this.FoFormObj = FoFormObj;
        this.SERVERPORT = szerverport;
        this.tray = tray;

    }

    @Override
    public void run() {
        L = FoForm.getL();
        start();
    }

    public void start() {

        while (!FoFormObj.SzalLekapcsolasa) {

            System.out.println(l.s(L,178));

            figyelesindul();
            try {
                serverSocket.close();
                serverSocket = null;
            } catch (IOException ex) {
                Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
                serverSocket = null;
                System.gc();
            }
            FoFormObj.hibavan_reset();

        }
        System.out.println(l.s(L,177));
        tray.uzenetek(FoFormObj, tray.getTrayIcon(), l.s(L,8), l.s(L,179), 0);

    }

    private void figyelesindul() {
        String indult = new Adatbevitel().getCurrentTimeStamp();

        tray.uzenetek(FoFormObj, tray.getTrayIcon(), l.s(L,8), l.s(L,180) + indult + "\n", 0);

        try {
            serverSocket = new ServerSocket();//ujrahasználható módban nyitott szerverport
            serverSocket.setReuseAddress(true);
            serverSocket.bind(new InetSocketAddress(SERVERPORT));
        } catch (IOException e) {
            System.out.println("audio_rec.FigyeloClass.figyelesindul()" + e);
            tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), l.s(L,117) + String.valueOf(SERVERPORT), 0);
            tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), e.toString(), 0);
            FoFormObj.SzalLekapcsolasa = true;
            FoFormObj.hibavan_reset();

            return;
        } finally {

        }

        while (!FoFormObj.SzalLekapcsolasa) {

            System.out.println(l.s(L,118));
            try {
                clientSocket = serverSocket.accept();
                tray.uzenetek(FoFormObj, tray.getTrayIcon(), l.s(L,8), l.s(L,119), 0);
            } catch (IOException e) {
                tray.uzenetek(FoFormObj, tray.getTrayIcon(), l.s(L,6), l.s(L,120), 0);
                tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), e.toString(), 0);

                try {
                    serverSocket.close();
                } catch (IOException ex1) {
                    tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), l.s(L,121), 0);
                    tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), ex1.toString(), 0);
                }

                return;
            }

            try {
                kout = new DataOutputStream(clientSocket.getOutputStream());
            } catch (IOException ex) {
                tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), l.s(L,122), 0);
                tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), ex.toString(), 0);
            }

            try {
                kin = new DataInputStream(new BufferedInputStream(clientSocket.getInputStream()));
            } catch (IOException ex) {
                tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), l.s(L,123), 0);
                tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), ex.toString(), 0);
            }
            kiszolgalasindul();

        }

    }

    private void kiszolgalasindul() {

        byte preuzenet = 0;
        String uzenet = null;

        try {
            preuzenet = kin.readByte();
        } catch (IOException ex) {
            tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), l.s(L,124), 0);
            tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), ex.toString(), 0);
        }

        String kilep = clientSocket.getInetAddress().getHostAddress();
        switch (preuzenet) {
            case 1:
                if ("127.0.0.1".equals(kilep)) {

                    tray.uzenetek(FoFormObj, tray.getTrayIcon(), l.s(L,8), clientSocket.getInetAddress().getHostAddress() + l.s(L,125), 0);
                    kiszolgalaslezar();
                    return;
                }
                break;
            case 2:

                break;
            case 3:
                System.out.println("Fájlátvitel.kiszolgalasindul()>>");
                if (FoFormObj.jCheckBox1.isSelected()); else {
                    try {
                        kout.writeByte(11);
                    } catch (IOException ex) {
                        Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    kiszolgalaslezar();
                    return;
                }

                try {
                    int idekuldjed;
//                    int kor = 0;
//                    while (kiszolgalok[segedszerver-1].isAlive()) {
//                        segedszerver++;
//
//                       
//                            kor++;
//                            if (kor > 1) {
//                                kout.writeInt(0);//erre a portra küldd.
//                                kout.flush();
//                                kiszolgalaslezar();
//                                return;
//                            }
//                        }
//                    }
                    if (segedszerver > 9) {
                        segedszerver = 0;
                    }
                    idekuldjed = SERVERPORT + segedszerver + 1;
                    try {

                        kiszolgalok[segedszerver] = new Thread(new AdatSzerverek(FoFormObj, tray, idekuldjed)); //osztályt adtam át
                        kiszolgalok[segedszerver].start();
                        kout.writeInt(idekuldjed);//erre a portra küldd.
                        kout.flush();
                        segedszerver++;
                        kiszolgalaslezar();
                        return;
                    } catch (Exception e) {

                        kout.writeByte(10);
                        kout.flush();
                    }
                } catch (IOException ex) {

                }
                adatfogadas("file");
                break;

            default:
                break;
        }

        kiszolgalaslezar();

    }

    public void adatfogadas(String mit) {
        long helyikulcs = 0;
        try {
            FoFormObj.kezdokulcs2 = kin.readLong();
            helyikulcs = FoFormObj.kezdokulcs2;
        } catch (IOException ex) {
            Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            buffmeret = kin.readInt();
        } catch (IOException ex) {
            Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        buff = new byte[buffmeret];
        System.out.println("Buffer size: " + buffmeret);
//        int darab = kin.readInt();
        long filemeret = 0;
        try {
            filemeret = kin.readLong();
        } catch (IOException ex) {
            Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        String neve = null;
        try {
            neve = kin.readUTF();
        } catch (IOException ex) {
            Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(l.s(L,129) + neve);
        System.out.println(l.s(L,130) + filemeret);
        fajlmentes(neve);
        long olvasott = 0;
        int var = 0;
        while (olvasott < filemeret) {

            if (olvasott + buffmeret > filemeret) {
                int ujmeret = (int) ((int) filemeret - olvasott);
                buff = new byte[ujmeret];
            }
            try {
                while (kin.available() < buff.length) {
//                    try {
//                        kout.writeByte(1);//lassítson a küldéssel a másik
//                    } catch (IOException ex) {
//                        Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
//                    }
//                    kout.flush();
                    if (kin.available() >= buff.length) {
                        var++;

                        break;
                    }

                }
            } catch (IOException ex) {
                Logger.getLogger(FoForm.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                kin.read(buff);
            } catch (IOException ex) {

                tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), l.s(L,131), 0);

                kiszolgalaslezar();

                return;
            }
            try {
                save.write(buff);
            } catch (IOException ex) {
                Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
            }

            olvasott += buffmeret;
            final ScheduledExecutorService executorService2 = Executors.newSingleThreadScheduledExecutor();
            executorService2.scheduleAtFixedRate(() -> {
                FoFormObj.jLabel14.setText(l.s(L,132) + String.valueOf((FoFormObj.fogadott += buffmeret) / 1024 / 1024) + " MB");
                executorService2.shutdown();
            }, 0, 1, TimeUnit.SECONDS);
//            System.out.println("Adatra várt: " + var + " | " + buffmeret + " bufferméret " + neve + ": " + filemeret + " byte " + olvasott + " fogadott byte "
//                    + "    " + (int) ((double) ((double) olvasott / (double) filemeret) * 100) + " %");
        }
        try {
            kout.writeUTF("OK");
            kout.flush();
        } catch (IOException ex) {
            Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            tray.uzenetek(FoFormObj, tray.getTrayIcon(), l.s(L,8), l.s(L,133) + var + " | " + buffmeret + " bufferméret " + neve + ": " + filemeret / 1024 / 1024 + " MB " + olvasott / 1024 / 1024 + " fogadott MB "
                    + "    " + (int) ((double) ((double) olvasott / (double) filemeret) * 100) + " %", 0);
            save.writeLong(FoFormObj.kezdokulcs2);
        } catch (IOException ex) {
            Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            save.close();
            save = null;
        } catch (IOException ex) {
            Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        if ("hang".equals(mit)) {
            new Kodolas(FoFormObj.Kulcs, new File(neve), FoFormObj, "fogad").run();
        }
        if ("file".equals(mit)) {
            FoFormObj.setSendFile(neve);
            FoFormObj.setSendFileName(neve);
            FoFormObj.kezdokulcs2 = helyikulcs;
            new Kodolas(FoFormObj.Kulcs, new File(neve), FoFormObj, "fajlfogadas").run();
        }
        if (FoFormObj.sikereskodolas) {
            tray.uzenetek(FoFormObj, tray.getTrayIcon(), l.s(L,8), l.s(L,134), 1);
        }

    }

    public void fajlmentes(String neve) {
        File kimenetifajl = new File(neve);
        try {
            save = new DataOutputStream(new FileOutputStream(kimenetifajl));
            tray.uzenetek(FoFormObj, tray.getTrayIcon(), l.s(L,8), l.s(L,135) + kimenetifajl.getName(), 0);
        } catch (FileNotFoundException ex) {
            System.out.println(kimenetifajl.getName() + l.s(L,136) + ex);

        }
    }

    private void kiszolgalaslezar() {

        try {
            clientSocket.close();

        } catch (IOException ex) {
            tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), ex.toString(), 0);
        }

        try {
            kout.flush();
        } catch (IOException ex) {
            Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            kin.close();
        } catch (IOException ex) {
            tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), ex.toString(), 0);
        }
        try {
            kout.close();
        } catch (IOException ex) {
            tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), ex.toString(), 0);
        }

        kin = null;
        kout = null;
        clientSocket = null;

        System.gc();

    }

}
