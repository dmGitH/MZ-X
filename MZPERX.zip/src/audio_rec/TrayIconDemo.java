/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package audio_rec;

/**
 *
 * @author dm
 */
import java.awt.*;
import java.awt.TrayIcon.MessageType;
import java.awt.event.*;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import javax.swing.*;
import javax.swing.text.AttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;

public class TrayIconDemo {
//    public static void main(String[] args) {
//        /* Use an appropriate Look and Feel */
//        try {
//            UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
//            //UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
//        } catch (UnsupportedLookAndFeelException ex) {
//            ex.printStackTrace();
//        } catch (IllegalAccessException ex) {
//            ex.printStackTrace();
//        } catch (InstantiationException ex) {
//            ex.printStackTrace();
//        } catch (ClassNotFoundException ex) {
//            ex.printStackTrace();
//        }
//        /* Turn off metal's use of bold fonts */
//        UIManager.put("swing.boldMetal", Boolean.FALSE);
//        //Schedule a job for the event-dispatching thread:
//        //adding TrayIcon.
//        SwingUtilities.invokeLater(new Runnable() {
//            public void run() {
//                createAndShowGUI();
//            }
//        });
//    }

    private String uzenetszam = "no-contact";
    private final String lekerdezve = "no-contact";
    private String webcim = "";
    private final int uzenetekszama = 0;
    private final int uzenetszamor = 0;
    private FoForm obj;
    final TrayIcon trayIcon = new TrayIcon(createImage("/ip.png", "tray icon"));
    
    static String L = "hu";
    LanguageClass l = new LanguageClass();

    public TrayIcon getTrayIcon() {
        return trayIcon;
    }

    public void setObj(FoForm obj) {
        this.obj = obj;
        uzenetek(obj, trayIcon, l.s(L,181), l.s(L,182), 1);
         L = FoForm.getL();
    }

    public void setWebcim(String webcim) {
        this.webcim = webcim;
    }

    public void setUzenetszam(String uzenetszambe) {
        this.uzenetszam = uzenetszambe;

//        if(obj!=null){
//            if(Integer.parseInt(uzenetszambe)>this.uzenetekszama){
////                obj.setVisible(true);
//                uzenetek(trayIcon,"SemotusWebApp Java Kliens ","Új üzenete jött.\nAz üzeneteinek száma: "+Integer.parseInt(uzenetszambe));
//            }
//        }
//        this.uzenetekszama = Integer.parseInt(uzenetszambe);
    }

//    public void setLekerdezve(String lekerdezve) {
//        this.lekerdezve = lekerdezve;
//    }
    public static boolean openWebpage(URI uri) {
        Desktop desktop = Desktop.isDesktopSupported() ? Desktop.getDesktop() : null;
        if (desktop != null && desktop.isSupported(Desktop.Action.BROWSE)) {
            try {
                desktop.browse(uri);
                return true;
            } catch (IOException e) {
            }
        }
        return false;
    }

    public static boolean openWebpage(URL url) {
        if (url == null) {
            return false;
        }
        try {
            return openWebpage(url.toURI());
        } catch (URISyntaxException e) {
            return false;
        }

    }

    public void uzenetek(FoForm obj, TrayIcon trayIcon, String focim, String uzenet, int megjelenit) {

        appendToPane(obj.jTextPane1, focim + "\n", Color.BLUE, 15);
        appendToPane(obj.jTextPane1, uzenet + "\n", Color.BLACK, 12);
        if (megjelenit == 1) {
            trayIcon.displayMessage(focim, uzenet, MessageType.INFO);
        }
    }

    public void uzenetek_warning(FoForm obj, TrayIcon trayIcon, String focim, String uzenet, int megjelenit) {
        appendToPane(obj.jTextPane1, focim + "\n", Color.ORANGE, 15);
        appendToPane(obj.jTextPane1, uzenet + "\n", Color.BLACK, 12);
        if (megjelenit == 1) {
            trayIcon.displayMessage(focim, uzenet, MessageType.WARNING);
        }
    }

    public void uzenetek_alert(FoForm obj, TrayIcon trayIcon, String focim, String uzenet, int megjelenit) {
        appendToPane(obj.jTextPane1, focim + "\n", Color.RED, 15);
        appendToPane(obj.jTextPane1, uzenet + "\n", Color.BLACK, 12);
        if (megjelenit == 1) {
            trayIcon.displayMessage(focim, uzenet, MessageType.ERROR);
        }
    }

    public void appendToPane(JTextPane tp, String msg, Color c, int size) {

        StyleContext sc = StyleContext.getDefaultStyleContext();
        AttributeSet aset = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, c);

        aset = sc.addAttribute(aset, StyleConstants.FontFamily, "Lucida Console");
        aset = sc.addAttribute(aset, StyleConstants.Alignment, StyleConstants.ALIGN_JUSTIFIED);
        aset = sc.addAttribute(aset, StyleConstants.FontSize, size);

        int len = tp.getDocument().getLength();
        tp.setCaretPosition(len);
        tp.setCharacterAttributes(aset, false);
        tp.replaceSelection(msg);
    }

    public void createAndShowGUI() {
        //Check the SystemTray support
        if (!SystemTray.isSupported()) {
            System.out.println("SystemTray is not supported");
            return;
        }
        final PopupMenu popup = new PopupMenu();

        final SystemTray tray = SystemTray.getSystemTray();

        // Create a popup menu components
        MenuItem aboutItem = new MenuItem(l.s(L,183));

        MenuItem cb1 = new MenuItem(l.s(L,184));
//        CheckboxMenuItem cb2 = new CheckboxMenuItem("Mutassa a tooltippet");

//        Menu displayMenu = new Menu("Display");
//        MenuItem errorItem = new MenuItem("Error");
//        MenuItem warningItem = new MenuItem("Warning");
//        MenuItem infoItem = new MenuItem("Info");
//        MenuItem noneItem = new MenuItem("None");
        MenuItem exitItem = new MenuItem("Exit");
        trayIcon.setImageAutoSize(true);
        trayIcon.setToolTip(l.s(L,185));
        //Add components to popup menu
        popup.add(aboutItem);
//        popup.addSeparator();
        popup.add(cb1);
//        popup.add(cb2);
        popup.addSeparator();
//        popup.add(displayMenu);
//        displayMenu.add(errorItem);
//        displayMenu.add(warningItem);
//        displayMenu.add(infoItem);
//        displayMenu.add(noneItem);
        popup.add(exitItem);

        trayIcon.setPopupMenu(popup);

        try {
            tray.add(trayIcon);
        } catch (AWTException e) {
            System.out.println(l.s(L,186));
            return;
        }

//        uzenetek(obj,trayIcon,"Semotus AdóVevő Kliens ","Az alkalmazás elindult");
        trayIcon.addActionListener((ActionEvent e) -> {
            //                JOptionPane.showMessageDialog(null,
//                        "Üzenetek száma: " + uzenetszam + "\nUtoljára lekérdezve: " + lekerdezve);
            try {
                obj.setVisible(true);
            } catch (Exception ex) {
                System.out.println(ex);
            }
        });

        aboutItem.addActionListener((ActionEvent e) -> {
            URL cim = null;
//                System.out.println("\nkapott url: "+webcim);
            if ("".equals(webcim)) {
                webcim = "https://semotus.hu";
            }
            try {

                cim = new URL(webcim);
            } catch (MalformedURLException ex) {
                JOptionPane.showMessageDialog(null,
                        l.s(L,187));
            }
//                System.out.println("\nURL: "+cim);
            openWebpage(cim);
        });

        cb1.addActionListener((ActionEvent e) -> {
            try {
                obj.setVisible(true);
            } catch (Exception ex) {
                System.out.println(ex);
            }
//                int cb1Id = e.getStateChange();
//                if (cb1Id == ItemEvent.SELECTED){
//                    trayIcon.setImageAutoSize(true);
//                } else {
//                    trayIcon.setImageAutoSize(false);
//                }
        });
//        cb2.addItemListener(new ItemListener() {
//            public void itemStateChanged(ItemEvent e) {
//                int cb2Id = e.getStateChange();
//                if (cb2Id == ItemEvent.SELECTED){
//                    trayIcon.setToolTip("Semotus üzenetellenörző kliens");
//                } else {
//                    trayIcon.setToolTip(null);
//                }
//            }
//        });
        ActionListener listener = (ActionEvent e) -> {
            MenuItem item = (MenuItem) e.getSource();
            //TrayIcon.MessageType type = null;
            System.out.println(item.getLabel());
            if (null != item.getLabel()) {
                switch (item.getLabel()) {
                    case "Error":
                        //type = TrayIcon.MessageType.ERROR;
                        trayIcon.displayMessage("Sun TrayIcon Demo",
                                "Hibaüzenet", TrayIcon.MessageType.ERROR);
                        break;
                    case "Warning":
                        //type = TrayIcon.MessageType.WARNING;
                        trayIcon.displayMessage("Sun TrayIcon Demo",
                                "Figyelmeztetés", TrayIcon.MessageType.WARNING);
                        break;
                    case "Info":
                        //type = TrayIcon.MessageType.INFO;
                        trayIcon.displayMessage("Sun TrayIcon Demo",
                                "Információ", TrayIcon.MessageType.INFO);
                        break;
                    case "None":
                        //type = TrayIcon.MessageType.NONE;
                        trayIcon.displayMessage("Sun TrayIcon Demo",
                                "Üzenet", TrayIcon.MessageType.NONE);
                        break;
                    default:
                        break;
                }
            }
        };

//        errorItem.addActionListener(listener);
//        warningItem.addActionListener(listener);
//        infoItem.addActionListener(listener);
//        noneItem.addActionListener(listener);
        exitItem.addActionListener((ActionEvent e) -> {
            tray.remove(trayIcon);
            System.exit(0);
        });
    }

    //Obtain the image URL
    public static Image createImage(String path, String description) {
        URL imageURL = TrayIconDemo.class.getResource(path);

        if (imageURL == null) {
            System.err.println("Resource not found: " + path);
            return null;
        } else {
            return (new ImageIcon(imageURL, description)).getImage();

        }
    }

}
