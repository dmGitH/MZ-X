/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package audio_rec;

import java.awt.Color;
import static java.lang.Thread.sleep;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dm
 */
public class EletjelClass implements Runnable {
    
    private final FoForm FoFormObj;
    static String L = "hu";
    LanguageClass l = new LanguageClass();
    
    TrayIconDemo tray;
    

    public EletjelClass(FoForm FoFormObj, TrayIconDemo tray) {
        this.FoFormObj = FoFormObj;
       
        this.tray = tray;
    }

        

    @Override
    public void run() {
        L=FoForm.getL();
        figyelesindul();
        tray.uzenetek(FoFormObj,tray.getTrayIcon(),l.s(L,8), l.s(L,172),0);
         FoFormObj.jTextPane1.setCaretPosition(FoFormObj.jTextPane1.getDocument().getLength());
         FoFormObj.jPFigyelo.setBackground(Color.red);
        System.out.println(l.s(L,173));
    }

    public void figyelesindul() {
        String valasz="";
        String ujvalasz="";
        do{
           
            System.out.println(l.s(L,174));
            
            
            try {
                if(!FoFormObj.SzalLekapcsolasa)new HttpCliens().sendPost(FoFormObj.url, FoFormObj.hash, "1", FoFormObj.nick);
                
                ujvalasz=new HttpCliens().sendPost(FoFormObj.url, FoFormObj.hash, "2", FoFormObj.nick);
            } catch (Exception ex) {
                 tray.uzenetek_alert(FoFormObj,tray.getTrayIcon(),l.s(L,6), l.s(L,175),1);
                Logger.getLogger(EletjelClass.class.getName()).log(Level.SEVERE, null, ex);
                System.out.println(l.s(L,6)+": "+ l.s(L,175));
                
            }
            if(valasz == null ? ujvalasz != null : !valasz.equals(ujvalasz)){
                FoFormObj.regisztraltak_keresese();
                valasz=ujvalasz;
                tray.uzenetek(FoFormObj,tray.getTrayIcon(),l.s(L,8), l.s(L,176),0);
            }
            try {
                sleep(FoFormObj.FIGYELESI_fRISSITESI_GYAKORISAG);
            } catch (InterruptedException ex) {
                Logger.getLogger(EletjelClass.class.getName()).log(Level.SEVERE, null, ex);
            }
            FoFormObj.list1.removeAll();
            FoFormObj.listahozad();
        }while(!FoFormObj.SzalLekapcsolasa);
    }
}
