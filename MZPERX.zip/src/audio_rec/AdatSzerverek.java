/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package audio_rec;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AdatSzerverek implements Runnable {

    int SERVERPORT;
    private final FoForm FoFormObj;
    ServerSocket serverSocket = null;
    boolean fut = true;
    boolean indul = true;
    TrayIconDemo tray;
    Socket clientSocket = null;
    DataOutputStream kout;
    DataInputStream kin;
    DataOutputStream save;
    String keyfile;
    DataInputStream key;
    Socket s;
    DataInputStream in;
    DataOutputStream out;

    Thread[] kiszolgalok = new Thread[10];

    String inputLine = null;

    String beolvas = null;
    int buffmeret = 40000;
    byte[] buff;
    long adatcrc = 0;
    static String L = "hu";
    LanguageClass l = new LanguageClass();

    public AdatSzerverek(FoForm FoFormObj, TrayIconDemo tray, int szerverport) {
        this.FoFormObj = FoFormObj;
        this.SERVERPORT = szerverport;
        this.tray = tray;

    }

    @Override
    public void run() {
         L=FoForm.getL();
        start();
    }

    public void start() {

        System.out.println(l.s(L,160)+SERVERPORT);

        figyelesindul();
        try {
            serverSocket.close();
            serverSocket = null;
        } catch (IOException ex) {
            Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
            serverSocket = null;
            System.gc();
        }
        

        System.out.println(l.s(L,161)+SERVERPORT);
        tray.uzenetek(FoFormObj, tray.getTrayIcon(), l.s(L,8), l.s(L,161)+SERVERPORT, 0);

    }

    private void figyelesindul() {
         

        try {
            serverSocket = new ServerSocket();//ujrahasználható módban nyitott szerverport
            serverSocket.setReuseAddress(true);
            serverSocket.bind(new InetSocketAddress(SERVERPORT));
        } catch (IOException e) {
            System.out.println(l.s(L,162)+SERVERPORT+" exception: " + e);
            tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), l.s(L,163) + String.valueOf(SERVERPORT), 0);
            tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), e.toString(), 0);
            FoFormObj.SzalLekapcsolasa = true;
            return;
        } finally {

        }

        System.out.println(l.s(L,164)+SERVERPORT);
        try {
            clientSocket = serverSocket.accept();
            tray.uzenetek(FoFormObj, tray.getTrayIcon(), l.s(L,8), l.s(L,165)+SERVERPORT, 0);
        } catch (IOException e) {
            tray.uzenetek(FoFormObj, tray.getTrayIcon(), l.s(L,6), l.s(L,166)+SERVERPORT, 0);
            tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), e.toString(), 0);

            try {
                serverSocket.close();
            } catch (IOException ex1) {
                tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), l.s(L,167), 0);
                tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), ex1.toString(), 0);
            }

            return;
        }

        try {
            kout = new DataOutputStream(clientSocket.getOutputStream());
        } catch (IOException ex) {
            tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), l.s(L,122), 0);
            tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), ex.toString(), 0);
        }

        try {
            kin = new DataInputStream(new BufferedInputStream(clientSocket.getInputStream()));
        } catch (IOException ex) {
            tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), l.s(L,123), 0);
            tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), ex.toString(), 0);
        }
        kiszolgalasindul();

    }

    private void kiszolgalasindul() {

        byte preuzenet = 0;


        try {
            preuzenet = kin.readByte();
        } catch (IOException ex) {
            tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), l.s(L,168), 0);
            tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), ex.toString(), 0);
        }


        switch (preuzenet) {
            case 1:
               break;
            case 2:

                break;
            case 3:
                System.out.println(l.s(L,169)+SERVERPORT);
                
                try {

                    kout.writeByte(10);
                    kout.flush();
                } catch (IOException ex) {

                }
                adatfogadas("file");
                break;

            default:
                break;
        }

        kiszolgalaslezar();

    }

    public void adatfogadas(String mit) {
        long helyikulcs = 0;
        try {
            FoFormObj.kezdokulcs2 = kin.readLong();
            helyikulcs = FoFormObj.kezdokulcs2;
        } catch (IOException ex) {
            Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            buffmeret = kin.readInt();
        } catch (IOException ex) {
            Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        buff = new byte[buffmeret];
        System.out.println("Buffer size: " + buffmeret);
//        int darab = kin.readInt();
        long filemeret = 0;
        try {
            filemeret = kin.readLong();
        } catch (IOException ex) {
            Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        String neve = null;
        try {
            neve = kin.readUTF();
        } catch (IOException ex) {
            Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Received file : " + neve);
        System.out.println("Received file size : " + filemeret);
        fajlmentes(neve);
        long olvasott = 0;
        int var = 0;
        while (olvasott < filemeret) {

            if (olvasott + buffmeret > filemeret) {
                int ujmeret = (int) ((int) filemeret - olvasott);
                buff = new byte[ujmeret];
            }
            try {
                while (kin.available() < buff.length) {
//                    try {
//                        kout.writeByte(1);//lassítson a küldéssel a másik
//                    } catch (IOException ex) {
//                        Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
//                    }
//                    kout.flush();
                    if (kin.available() >= buff.length) {
                        var++;

                        break;
                    }

                }
            } catch (IOException ex) {
                Logger.getLogger(FoForm.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                kin.read(buff);
            } catch (IOException ex) {

                tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), l.s(L,170), 0);

                kiszolgalaslezar();

                return;
            }
            try {
                save.write(buff);
            } catch (IOException ex) {
                Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
            }

            olvasott += buffmeret;
            final ScheduledExecutorService executorService2 = Executors.newSingleThreadScheduledExecutor();
            executorService2.scheduleAtFixedRate(() -> {
                FoFormObj.jLabel14.setText(l.s(L,84) + String.valueOf((FoFormObj.fogadott += buffmeret) / 1024 / 1024) + " MB");
                executorService2.shutdown();
            }, 0, 1, TimeUnit.SECONDS);
//            System.out.println("Adatra várt: " + var + " | " + buffmeret + " bufferméret " + neve + ": " + filemeret + " byte " + olvasott + " fogadott byte "
//                    + "    " + (int) ((double) ((double) olvasott / (double) filemeret) * 100) + " %");
        }
        try {
            kout.writeUTF("OK");
            kout.flush();
        } catch (IOException ex) {
            Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            tray.uzenetek(FoFormObj, tray.getTrayIcon(), l.s(L,8), l.s(L,133) + var + " | " + buffmeret + " buffer size " + neve + ": " + filemeret / 1024 / 1024 + " MB " + olvasott / 1024 / 1024 + " fogadott MB "
                    + "    " + (int) ((double) ((double) olvasott / (double) filemeret) * 100) + " %", 0);
            save.writeLong(FoFormObj.kezdokulcs2);
        } catch (IOException ex) {
            Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            save.close();
            save = null;
        } catch (IOException ex) {
            Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        if ("hang".equals(mit)) {
            new Kodolas(FoFormObj.Kulcs, new File(neve), FoFormObj, "fogad").run();
        }
        if ("file".equals(mit)) {
            FoFormObj.setSendFile(neve);
            FoFormObj.setSendFileName(neve);
            FoFormObj.kezdokulcs2 = helyikulcs;
            new Kodolas(FoFormObj.Kulcs, new File(neve), FoFormObj, "fajlfogadas").run();
        }
        if (FoFormObj.sikereskodolas) {
            tray.uzenetek(FoFormObj, tray.getTrayIcon(), l.s(L,8), l.s(L,134), 1);
        }

    }

    public void fajlmentes(String neve) {
        File kimenetifajl = new File(neve);
        try {
            save = new DataOutputStream(new FileOutputStream(kimenetifajl));
            tray.uzenetek(FoFormObj, tray.getTrayIcon(), l.s(L,8), l.s(L,135) + kimenetifajl.getName(), 0);
        } catch (FileNotFoundException ex) {
            System.out.println(kimenetifajl.getName() + l.s(L,136) + ex);

        }
    }

    private void kiszolgalaslezar() {

        try {
            clientSocket.close();

        } catch (IOException ex) {
            tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), ex.toString(), 0);
        }

        try {
            kout.flush();
        } catch (IOException ex) {
            Logger.getLogger(FigyeloClass.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            kin.close();
        } catch (IOException ex) {
            tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), ex.toString(), 0);
        }
        try {
            kout.close();
        } catch (IOException ex) {
            tray.uzenetek_alert(FoFormObj, tray.getTrayIcon(), l.s(L,6), ex.toString(), 0);
        }

        kin = null;
        kout = null;
        clientSocket = null;

        System.gc();

    }
}
