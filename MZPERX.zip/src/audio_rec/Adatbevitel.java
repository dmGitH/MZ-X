/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package audio_rec;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author dm
 */
public class Adatbevitel {

    public int urlellenorzes(String url) {
        if (url.indexOf("author: matyo95") != -1) {
            return 1;
        } else if (url.indexOf("301") != -1) {
            return 2;
        } else {
            return 3;
        }
    }

    public int kodellenorzes(String klienskod) {
        if (klienskod.length() != 40) {
            return 0;
        } else {
            return 1;
        }
    }

    public String getCurrentTimeStamp() {
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//dd/MM/yyyy
        Date now = new Date();
        String strDate = sdfDate.format(now);
        return strDate;
    }
    public String fajlnev() {
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy.MM.dd_HH_mm_ss");//dd/MM/yyyy
        Date now = new Date();
        String strDate = sdfDate.format(now);
        return strDate;
    }
    
    public boolean szameastring(String a){
    
        try{
            int b = Integer.parseInt(a);
        }catch(Exception e){
            return false;
        }
        return true;
    }
    
    public boolean kulcsfileellenorzes(long hossza){
    
        return hossza >= 1024*1024*5;
    }
}
