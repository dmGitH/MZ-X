/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package audio_rec;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException;
import static java.lang.Thread.sleep;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.sound.sampled.LineUnavailableException;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import org.apache.commons.codec.binary.Base64;

/**
 *
 * @author dm
 */
public final class FoForm extends javax.swing.JFrame {

    static String L = "hu";
    static int FELVETEL_IDO = 10000; //
    int FIGYELESI_fRISSITESI_GYAKORISAG = 10000;
    RandomAccessFile randomakulcs;
    File Kulcs;
    String url = "";
    menteshely obj = new menteshely();
    private final String kulcsfMappa = "";
    private String kulcsfile = "";
    TrayIconDemo tray = new TrayIconDemo();
    String nick = "";
    String hash = "";
    ArrayList<String> iplist = new ArrayList<>();
    ArrayList<String> nevlist = new ArrayList<>();
    Boolean adasban = false;
    Audio_rdcorder hang = new Audio_rdcorder();
    int sec = 0;
    int beszedido = 25;
    Thread Figyelo;
    Thread Eletjel;
    Thread FileFigyelo;

    boolean FigyeloLekapcsolasa = false;
    boolean SzalLekapcsolasa = false;
    private JPanel topPanel;
    String jelszo = "";
    String SendFileName = "";
    String SendFile = "";
    boolean sikereskodolas = false;
    boolean sikereskuldes = false;
    boolean sikeresfajlkodolas = false;
    boolean sikeresfajlkuldes = false;
    Socket kuldoSocket = null;
    DataOutputStream out = null;
    DataInputStream kodoltfile = null;
    DataInputStream in = null;
    boolean kodoltzarva = false;
    long kezdokulcs = 0;
    long kezdokulcs2 = 0;
    String kuldottfile = "";
    long fogadott = 0;
    long kuldott = 0;
    ChatForm chat = new ChatForm();
    LanguageClass l = new LanguageClass();

    public static String getL() {
        return L;
    }

    public void setSendFileName(String SendFileName) {
        this.SendFileName = SendFileName;
    }

    public void setSendFile(String SendFile) {
        this.SendFile = SendFile;
    }

    public void setKuldottfile(String kuldottfile) {
        this.kuldottfile = kuldottfile;
        if (!"".equals(kuldottfile)) {
            fajlkuldes();
        }
    }

    public void setTopPanel(JPanel topPanel) {
        this.topPanel = topPanel;
    }

    /**
     * Creates new form FoForm
     */
    public FoForm() {

        try {
            URL resource = getClass().getResource("/talcaicon.jpg");
            BufferedImage image = ImageIO.read(resource);
            setIconImage(image);

        } catch (IOException e) {
            System.out.println(e);
        }
        setSize(new Dimension(250, 250));
        setTitle("Semotus MZ/X");
        initComponents();

        feliratokbeallitasa();

        final JPopupMenu popup = new JPopupMenu();
        // New project menu item
        JMenuItem menuItem = new JMenuItem(l.s(L, 1),
                new ImageIcon(""));
        menuItem.setMnemonic(KeyEvent.VK_P);
//        menuItem.getAccessibleContext().setAccessibleDescription(
//                "New Project");
        menuItem.addActionListener((ActionEvent e) -> {
//            JOptionPane.showMessageDialog(list1, "Törölje a kijelölt fájlt és a wavját is!");
            //
            selectuzenet_torlese(list1.getSelectedIndex());

        });
        popup.add(menuItem);
        // New File menu item
        menuItem = new JMenuItem(l.s(L, 2),
                new ImageIcon(""));
        menuItem.setMnemonic(KeyEvent.VK_F);
        menuItem.addActionListener((ActionEvent e) -> {
//            JOptionPane.showMessageDialog(list1, "Töröljön minden hangüzenetet.");
            list1.removeAll();
            listahozad();
        });
        popup.add(menuItem);
//        // New File menu item
//        menuItem = new JMenuItem("Törölje a nem .sem kiterjesztésű fájlokat a munkakönyvtárból",
//                new ImageIcon("src/wav.png"));
//        menuItem.setMnemonic(KeyEvent.VK_F);
//        menuItem.addActionListener((ActionEvent e) -> {
//            JOptionPane.showMessageDialog(list1, "Töröljön minden nem .sem kiterjesztésü fájlt");
//        });
//        popup.add(menuItem);
//        menuItem = new JMenuItem("Minden fájl törlése a munka könyvtárból",
//                new ImageIcon("src/bomb.png"));
//        menuItem.setMnemonic(KeyEvent.VK_F);
//        menuItem.addActionListener((ActionEvent e) -> {
//            JOptionPane.showMessageDialog(list1, "Töröljön minden fájlt a munkakönyvtárból");
//        });
//        popup.add(menuItem);

        // add mouse listener
        list1.addMouseListener(new MouseAdapter() {

            @Override
            public void mousePressed(MouseEvent e) {
                showPopup(e);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                showPopup(e);
            }

            private void showPopup(MouseEvent e) {
                if (e.isPopupTrigger()) {
//                    list1.select(e.getY() / (list1.getFont().getSize()) + list1.getSelectedIndex());

                    popup.show(e.getComponent(),
                            e.getX(), e.getY());
                }
            }
        });

        final JPopupMenu popup2 = new JPopupMenu();
        // New project menu item
        JMenuItem menuItem2 = new JMenuItem(l.s(L, 3),
                new ImageIcon(""));
        menuItem2.setMnemonic(KeyEvent.VK_P);
//        menuItem2.getAccessibleContext().setAccessibleDescription(
//                "New Project");
        menuItem2.addActionListener((ActionEvent e) -> {
//            JOptionPane.showMessageDialog(list1, "Törölje a kijelölt fájlt és a wavját is!");
            //
            jTextPane1.setText("");

        });
        popup2.add(menuItem2);

        JMenuItem menuItem3 = new JMenuItem(l.s(L, 4),
                new ImageIcon(""));
        menuItem3.setMnemonic(KeyEvent.VK_P);
//        menuItem2.getAccessibleContext().setAccessibleDescription(
//                "New Project");
        menuItem3.addActionListener((ActionEvent e) -> {
//            JOptionPane.showMessageDialog(list1, "Törölje a kijelölt fájlt és a wavját is!");
            //
            StringSelection stringSelection = new StringSelection(jTextPane1.getText());
            Clipboard clpbrd = Toolkit.getDefaultToolkit().getSystemClipboard();
            clpbrd.setContents(stringSelection, null);

        });
        popup2.add(menuItem3);
        jTextPane1.addMouseListener(new MouseAdapter() {

            @Override
            public void mousePressed(MouseEvent e) {
                showPopup2(e);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                showPopup2(e);
            }

            private void showPopup2(MouseEvent e) {
                if (e.isPopupTrigger()) {
//                    list1.select(e.getY() / (list1.getFont().getSize()) + list1.getSelectedIndex());

                    popup2.show(e.getComponent(),
                            e.getX(), e.getY());
                }
            }
        });

        jLabel12.setVisible(false);
        for (int i = 50; i < 64000; i++) {
            jComboBox2.addItem(String.valueOf(i));
            jComboBox3.addItem(String.valueOf(i));
        }
        jComboBox2.setSelectedIndex(9545);
        jComboBox3.setSelectedIndex(5909);
        tray.createAndShowGUI();
        //frame középen legyen a képernyőn
        Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (int) ((dimension.getWidth() - this.getWidth()) / 2);
        int y = (int) ((dimension.getHeight() - this.getHeight()) / 2);
        this.setLocation(x, y);
//        String a="أَشْهَدُ أَنْ لا إِلَهَ إِلا اللَّهُ";
//        print(a);
        listahozad();
//        tray.uzenetek(this, tray.getTrayIcon(), l.s(L,8),a , 1);

    }

    public void print(String msg, Object... args) {
        try {
            PrintStream ps = new PrintStream(System.out, true, "UTF-8");
            ps.println(String.format(msg, args));
        } catch (UnsupportedEncodingException error) {
            System.err.println(error);
            System.exit(0);
        }
    }

    public void feliratokbeallitasa() {

        jLabel1.setText(l.s(L, 45));
        jTextField1.setToolTipText(l.s(L, 46));
        jButton2.setText(l.s(L, 47));
        jButton2.setToolTipText(l.s(L, 48));
        jButton3.setText(l.s(L, 49));
        jButton3.setToolTipText(l.s(L, 50));
        jPanel2.setToolTipText(l.s(L, 51));
        jLabel8.setText(l.s(L, 52));
        jComboBox1.setToolTipText(l.s(L, 53));
        jLabel9.setText(l.s(L, 54));
        jLabel6.setText(l.s(L, 55));
        jLabel7.setText(l.s(L, 56));
        jLabel10.setText(l.s(L, 57));
        jButton1.setText(l.s(L, 58));
        jButton1.setToolTipText(l.s(L, 59));
        jButton5.setText(l.s(L, 60));
        jButton5.setToolTipText(l.s(L, 61));
        jSlider2.setToolTipText(l.s(L, 62));
        jLabel5.setText(l.s(L, 63));
        jButton6.setToolTipText(l.s(L, 64));
        jLabel15.setText(l.s(L, 65));
        jLabel14.setText(l.s(L, 66));
        jCheckBox1.setText(l.s(L, 67));
        jButton4.setText(l.s(L, 68));
        JBText.setToolTipText(l.s(L, 69));
        jCheckBox3.setText(l.s(L, 70));
        jComboBox2.setToolTipText(l.s(L, 71));
        jComboBox3.setToolTipText(l.s(L, 72));
        jPanel7.setToolTipText(l.s(L, 73));

    }

    public void listahozad() {

        File dir = new File(System.getProperty("user.dir"));
        File[] filesList = dir.listFiles();
        for (File file : filesList) {
            if (file.isFile()) {

                list1.add(file.getName());

            }
        }
    }

    public void selectuzenet_torlese(int kivalasztott) {
        String sor = list1.getItem(kivalasztott);
        File delete = new File(sor);
        delete.delete();
        delete = new File(sor + ".wav");
        delete.delete();
        list1.removeAll();
        listahozad();
    }

    public void setKulcsfile(String kulcsfile) {
        this.kulcsfile = kulcsfile;
        Kulcs = new File(kulcsfile);
        Adatbevitel ell = new Adatbevitel();
        if (ell.kulcsfileellenorzes(Kulcs.length())); else {
            JOptionPane.showMessageDialog(null,
                    l.s(L, 5));
            tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 6), l.s(L, 5), 1);
            Kulcs = null;
            this.kulcsfile = "";
            jButton3.setEnabled(false);
            jLabel12.setVisible(false);

            return;
        }
        jButton3.setEnabled(true);
        jLabel12.setVisible(true);

    }

    public void setUrl(String url) {
        this.url = url;
        System.out.println(url);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jPanel4 = new javax.swing.JPanel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jPSzerver = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPFigyelo = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jComboBox3 = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jProgressBar1 = new javax.swing.JProgressBar();
        jLabel10 = new javax.swing.JLabel();
        jSlider1 = new javax.swing.JSlider();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jSlider2 = new javax.swing.JSlider();
        jLabel5 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        list1 = new java.awt.List();
        jPanel8 = new javax.swing.JPanel();
        jCheckBox1 = new javax.swing.JCheckBox();
        jButton4 = new javax.swing.JButton();
        jCheckBox2 = new javax.swing.JCheckBox();
        jComboBox4 = new javax.swing.JComboBox<>();
        jCheckBox3 = new javax.swing.JCheckBox();
        jPanel9 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        JBText = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));
        setBounds(new java.awt.Rectangle(0, 0, 0, 0));
        setMinimumSize(new java.awt.Dimension(732, 785));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(102, 102, 102));
        jPanel1.setMinimumSize(new java.awt.Dimension(742, 723));

        jTextField1.setBackground(new java.awt.Color(0, 0, 0));
        jTextField1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(255, 153, 0));
        jTextField1.setToolTipText("");
        jTextField1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0), 2));

        jButton3.setToolTipText("");
        jButton3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 255, 255), 2));
        jButton3.setEnabled(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton2.setToolTipText("");
        jButton2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 255, 255), 2));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(255, 0, 0));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 255, 255), 2));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 18, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        jComboBox1.setToolTipText("");
        jComboBox1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 255, 255), 2));
        jComboBox1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jComboBox1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jComboBox1MouseExited(evt);
            }
        });

        jTextPane1.setBackground(new java.awt.Color(204, 204, 255));
        jTextPane1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jTextPane1.setForeground(new java.awt.Color(0, 0, 0));
        jTextPane1.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        jTextPane1.setMaximumSize(new java.awt.Dimension(4, 20));
        jScrollPane1.setViewportView(jTextPane1);
        jTextPane1.getAccessibleContext().setAccessibleParent(jTextPane1);

        jPanel4.setBackground(new java.awt.Color(51, 51, 51));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0), 2));

        jComboBox2.setBackground(new java.awt.Color(0, 255, 255));
        jComboBox2.setToolTipText("");

        jLabel6.setForeground(new java.awt.Color(153, 255, 255));

        jPSzerver.setBackground(new java.awt.Color(255, 0, 0));
        jPSzerver.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 255, 255), 2));
        jPSzerver.setToolTipText("Szerverportod állapota");

        javax.swing.GroupLayout jPSzerverLayout = new javax.swing.GroupLayout(jPSzerver);
        jPSzerver.setLayout(jPSzerverLayout);
        jPSzerverLayout.setHorizontalGroup(
            jPSzerverLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPSzerverLayout.setVerticalGroup(
            jPSzerverLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        jLabel8.setForeground(new java.awt.Color(153, 255, 255));

        jPFigyelo.setBackground(new java.awt.Color(255, 0, 0));
        jPFigyelo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 255, 255), 2));
        jPFigyelo.setToolTipText("A php szerverrel kapcsolatos állapotod.");

        javax.swing.GroupLayout jPFigyeloLayout = new javax.swing.GroupLayout(jPFigyelo);
        jPFigyelo.setLayout(jPFigyeloLayout);
        jPFigyeloLayout.setHorizontalGroup(
            jPFigyeloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 19, Short.MAX_VALUE)
        );
        jPFigyeloLayout.setVerticalGroup(
            jPFigyeloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        jLabel9.setForeground(new java.awt.Color(153, 255, 255));

        jComboBox3.setBackground(new java.awt.Color(255, 102, 0));
        jComboBox3.setToolTipText("");

        jLabel7.setForeground(new java.awt.Color(153, 255, 255));

        jPanel7.setBackground(new java.awt.Color(255, 153, 0));
        jPanel7.setToolTipText("");
        jPanel7.setCursor(new java.awt.Cursor(java.awt.Cursor.N_RESIZE_CURSOR));
        jPanel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel7MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 18, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPFigyelo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPSzerver, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6)
                        .addComponent(jLabel8))
                    .addComponent(jPSzerver, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel7))
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPFigyelo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel5.setBackground(new java.awt.Color(0, 0, 0));
        jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0), 3));

        jProgressBar1.setForeground(new java.awt.Color(255, 153, 0));

        jLabel10.setForeground(new java.awt.Color(153, 255, 255));

        jSlider1.setToolTipText("A hangfelvétel egyhuzamban történő rögzítésének ideje. (Max 1 perc)");
        jSlider1.setValue(25);
        jSlider1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSlider1StateChanged(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("0");

        jLabel3.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("30");

        jLabel4.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("60 sec");

        jPanel3.setBackground(new java.awt.Color(153, 255, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        jButton1.setBackground(new java.awt.Color(51, 51, 51));
        jButton1.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 153, 0));
        jButton1.setToolTipText("");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 3));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jButton5.setBackground(new java.awt.Color(51, 51, 51));
        jButton5.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 102));
        jButton5.setToolTipText("");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jSlider2.setToolTipText("");
        jSlider2.setValue(0);

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));

        jButton6.setText("T");
        jButton6.setToolTipText("");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(10, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jProgressBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 398, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel5Layout.createSequentialGroup()
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel5Layout.createSequentialGroup()
                                    .addGap(6, 6, 6)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(156, 156, 156)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel5Layout.createSequentialGroup()
                                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                            .addGap(22, 22, 22)
                                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(74, 74, 74))
                                        .addGroup(jPanel5Layout.createSequentialGroup()
                                            .addGap(18, 18, 18)
                                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jSlider2, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGap(18, 18, 18)
                                            .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGap(14, 14, 14))
                        .addGroup(jPanel5Layout.createSequentialGroup()
                            .addComponent(jSlider1, javax.swing.GroupLayout.PREFERRED_SIZE, 398, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addContainerGap()))))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jProgressBar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(jSlider1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGap(0, 26, Short.MAX_VALUE)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jButton6)
                                    .addGroup(jPanel5Layout.createSequentialGroup()
                                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(6, 6, 6)
                                        .addComponent(jSlider2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel5)))
                        .addGap(13, 13, 13))))
        );

        list1.setBackground(new java.awt.Color(0, 0, 0));
        list1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        list1.setForeground(new java.awt.Color(255, 153, 0));
        list1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                list1ActionPerformed(evt);
            }
        });

        jPanel8.setBackground(new java.awt.Color(51, 51, 51));
        jPanel8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 255, 255), 2));

        jCheckBox1.setForeground(new java.awt.Color(153, 255, 255));
        jCheckBox1.setSelected(true);

        jButton4.setBackground(new java.awt.Color(102, 102, 102));
        jButton4.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(153, 255, 255));
        jButton4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 255, 255), 2));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jCheckBox2.setForeground(new java.awt.Color(153, 255, 255));
        jCheckBox2.setSelected(true);
        jCheckBox2.setText("Auto Buffer");
        jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox2ActionPerformed(evt);
            }
        });

        jComboBox4.setForeground(new java.awt.Color(153, 255, 255));
        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1024", "2048", "4096", "8192", "16386", "32768" }));
        jComboBox4.setSelectedIndex(1);
        jComboBox4.setEnabled(false);

        jCheckBox3.setForeground(new java.awt.Color(153, 255, 255));
        jCheckBox3.setSelected(true);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jCheckBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel8Layout.createSequentialGroup()
                                .addGap(27, 27, 27)
                                .addComponent(jCheckBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGroup(jPanel8Layout.createSequentialGroup()
                            .addGap(26, 26, 26)
                            .addComponent(jCheckBox2))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jCheckBox1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jCheckBox2, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jCheckBox3)
                .addContainerGap())
        );

        jPanel9.setBackground(new java.awt.Color(51, 51, 51));
        jPanel9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0), 2));

        jLabel15.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(153, 255, 255));

        jLabel14.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(153, 255, 255));

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel10.setBackground(new java.awt.Color(51, 51, 51));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons-192.png"))); // NOI18N
        jLabel11.setToolTipText("semotus.hu");
        jLabel11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 51), 4));
        jLabel11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel11.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
        });

        JBText.setBackground(new java.awt.Color(102, 102, 102));
        JBText.setForeground(new java.awt.Color(153, 255, 255));
        JBText.setText("Chat");
        JBText.setToolTipText("");
        JBText.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 255, 255), 2));
        JBText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JBTextActionPerformed(evt);
            }
        });

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/eng.png"))); // NOI18N
        jLabel13.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel13.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel13MouseClicked(evt);
            }
        });

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hun.png"))); // NOI18N
        jLabel16.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel16MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(JBText, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel11)
                        .addGap(34, 34, 34)
                        .addComponent(jLabel13))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(218, 218, 218)
                        .addComponent(jLabel16)))
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel16)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(JBText, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(list1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(list1, javax.swing.GroupLayout.PREFERRED_SIZE, 305, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lock2.png"))); // NOI18N

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 255, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 425, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel12))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(6, 6, 6))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(20, 20, 20))))
                    .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jComboBox1)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(32, Short.MAX_VALUE))
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 712, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        FoForm.this.setVisible(false);
        tray.setObj(this);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        try {
            // TODO add your handling code here:
            int localbeszedido = jSlider1.getValue();
            jSlider1.setValue(0);
            sleep(100);
            jSlider1.setValue(localbeszedido);

        } catch (InterruptedException ex) {
            Logger.getLogger(FoForm.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (jPanel2.getBackground().getRed() == 255) {
            tray.uzenetek_warning(this, tray.getTrayIcon(), l.s(L, 7), l.s(L, 9), 1);
            return;
        }
        jSlider1.setValue(beszedido);
        start();
        tray.uzenetek(this, tray.getTrayIcon(), l.s(L, 8), l.s(L, 10), 1);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jSlider1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSlider1StateChanged
        // TODO add your handling code here:
        beszedido = jSlider1.getValue();
    }//GEN-LAST:event_jSlider1StateChanged

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:

        obj.nullFileChooser(kulcsfMappa);
        obj.setVisible(true);
        obj.setObj(this);
        obj.setMiertkellafilechuser(3);
        obj.setTray(tray);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        String valasz = "";
        if (l.s(L, 12).equals(jButton3.getText())) {
            try {
                valasz = new HttpCliens().sendPost(url, hash, "3", nick);
            } catch (Exception ex) {
                tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 6), Kulcs.getName() + l.s(L, 13), 0);
                System.out.println(l.s(L, 13) + ex);
            }
        } else {
            if (jComboBox2.getSelectedIndex() == jComboBox3.getSelectedIndex()) {
                JOptionPane.showMessageDialog(null,
                        l.s(L, 14));
            }
            hash = "";
            try {
                // TODO add your handling code here:
                randomakulcs = new RandomAccessFile(Kulcs.getAbsoluteFile(), "rw");
            } catch (FileNotFoundException ex) {

                System.out.println("audio_rec.FoForm.jButton3ActionPerformed()" + ex);
                tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 6), Kulcs.getName() + l.s(L, 15), 0);
            }
            byte[] hasalo = new byte[2048];

            for (int i = 0; i < 10; i++) {
                try {
                    randomakulcs.seek(((long) Kulcs.length() / 10) * i);

                } catch (IOException ex) {
                    Logger.getLogger(FoForm.class
                            .getName()).log(Level.SEVERE, null, ex);
                }
                try {
                    randomakulcs.read(hasalo);

                } catch (IOException ex) {
                    Logger.getLogger(FoForm.class
                            .getName()).log(Level.SEVERE, null, ex);
                }
                hash = hash + Arrays.toString(hasalo);

            }

            hash = HashClass.ShaToString(hash, "SHA-512");
            //        tray.uzenetek(tray.getTrayIcon(), "Hashertek", hash);
            nick = jTextField1.getText();
            if (nick.length() < 4) {

                tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 7), l.s(L, 16), 1);
                return;
            }

            try {
                valasz = new HttpCliens().sendPost(url, hash, "1", nick);
            } catch (Exception ex) {
                tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 6), Kulcs.getName() + l.s(L, 17), 1);
                System.out.println(l.s(L, 17) + ex);
            }
            try {
                randomakulcs.seek(0);

            } catch (IOException ex) {
                Logger.getLogger(FoForm.class
                        .getName()).log(Level.SEVERE, null, ex);
            }
            try {
                randomakulcs.close();

            } catch (IOException ex) {
                Logger.getLogger(FoForm.class
                        .getName()).log(Level.SEVERE, null, ex);
            }

        }
        if (null != valasz) {
            switch (valasz) {
                case "upd":
                    tray.uzenetek(this, tray.getTrayIcon(), l.s(L, 8), l.s(L, 18), 0);
                    beregisztralva();
                    break;
                case "reg":
                    tray.uzenetek(this, tray.getTrayIcon(), l.s(L, 8), l.s(L, 19), 0);
                    beregisztralva();
                    break;
                case "Error":
                    tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 6), l.s(L, 20), 0);
                    break;
                case "Ok":
                    tray.uzenetek(this, tray.getTrayIcon(), l.s(L, 8), l.s(L, 21), 0);
                    regtorlese();
                    break;
                case "nincs":
                    tray.uzenetek(this, tray.getTrayIcon(), l.s(L, 8), l.s(L, 22), 0);
                    regtorlese();
                    break;
                default:
                    break;
            }
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void list1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_list1ActionPerformed
        // TODO add your handling code here:
        String lead = list1.getSelectedItem();
        File kulcsolando = new File(lead);

        RandomAccessFile kulcskereses = null;

        try {
            kulcskereses = new RandomAccessFile(kulcsolando, "r");
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FoForm.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            kulcskereses.seek(kulcsolando.length() - 8);
        } catch (IOException ex) {
            Logger.getLogger(FoForm.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            System.out.println(kulcskereses.getFilePointer());
        } catch (IOException ex) {
            Logger.getLogger(FoForm.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            kezdokulcs2 = kulcskereses.readLong();
        } catch (IOException ex) {
            Logger.getLogger(FoForm.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            kulcskereses.close();
        } catch (IOException ex) {
            Logger.getLogger(FoForm.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            new Kodolas(Kulcs, kulcsolando, this, "fogad").run();
        } catch (Exception e) {
            try {
                beepClass.tone(((int) (Math.random() * 5000)), ((int) (Math.random() * 1000)), Math.random());
            } catch (LineUnavailableException ex) {
                Logger.getLogger(FoForm.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
//        if (sikereskodolas) {
//            MakeSound play = new MakeSound();
//            play.playSound(lead+"wav");
//            
//        }
    }//GEN-LAST:event_list1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed

        obj.nullFileChooser(kulcsfMappa);
        obj.setVisible(true);
        obj.setObj(this);
        obj.setMiertkellafilechuser(4);
        obj.setTray(tray);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked

        //                System.out.println("\nkapott url: "+webcim);
        try {

            TrayIconDemo.openWebpage(new URL("https://semotus.hu"));
        } catch (MalformedURLException ex) {
            JOptionPane.showMessageDialog(null,
                    l.s(L, 23));
        }
        //                System.out.println("\nURL: "+cim);

    }//GEN-LAST:event_jLabel11MouseClicked

    private void jCheckBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox2ActionPerformed
        // TODO add your handling code here:
        if (jCheckBox2.isSelected()) {
            jComboBox4.setEnabled(false);
        }
        if (!jCheckBox2.isSelected()) {
            jComboBox4.setEnabled(true);
        }
    }//GEN-LAST:event_jCheckBox2ActionPerformed

    private void jPanel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel7MouseClicked
        int index = jComboBox3.getSelectedIndex();
        jComboBox3.setSelectedIndex(jComboBox2.getSelectedIndex());
        jComboBox2.setSelectedIndex(index);
        Color orszin = jComboBox3.getBackground();
        jComboBox3.setBackground(jComboBox2.getBackground());
        jComboBox2.setBackground(orszin);

    }//GEN-LAST:event_jPanel7MouseClicked

    private void jComboBox1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBox1MouseEntered
        // TODO add your handling code here:

//        jComboBox1.showPopup();

    }//GEN-LAST:event_jComboBox1MouseEntered

    private void jComboBox1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jComboBox1MouseExited


    }//GEN-LAST:event_jComboBox1MouseExited

    private void JBTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JBTextActionPerformed
        try {
            chat.setObj(this);
            chat.setVisible(true);
        } catch (Exception e) {
            tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 6), l.s(L, 24), 0);
        }

    }//GEN-LAST:event_JBTextActionPerformed

    private void jLabel13MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel13MouseClicked
        // TODO add your handling code here:

        L = "en";

        feliratokbeallitasa();
        chat=null; obj=null;
        chat=new ChatForm(); chat.feliratokbeallitasa();
        obj=new menteshely(); obj.feliratokbeallitasa();
    }//GEN-LAST:event_jLabel13MouseClicked

    private void jLabel16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel16MouseClicked
        // TODO add your handling code here:
        L = "hu";

        feliratokbeallitasa();
         chat=null; obj=null;
        chat=new ChatForm(); chat.feliratokbeallitasa();
        obj=new menteshely(); obj.feliratokbeallitasa();
    }//GEN-LAST:event_jLabel16MouseClicked

    public void start() {
        hang.setFoFormObj(this);
        SendFileName = "";
        final ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
        ScheduledFuture<?> scheduleAtFixedRate = executorService.scheduleAtFixedRate(() -> {

            jButton1.setEnabled(false);
            jButton1.setText(l.s(L, 25));
            jButton1.setForeground(Color.red);

            Color old = jPanel3.getBackground();
            jPanel3.setBackground(Color.orange);

            System.out.println(l.s(L, 26));

            if (hang.rogzit(jSlider1.getValue() * FELVETEL_IDO)) {
                System.out.println(l.s(L, 27));
                tray.uzenetek(this, tray.getTrayIcon(), l.s(L, 8), l.s(L, 28), 1);
                if (!"".equals(SendFileName)) {
                    kuldje();
                }

            } else {
                System.out.println(l.s(L, 29));
                tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 6), l.s(L, 29), 1);
            }
            System.out.println("**************************");
            jButton1.setEnabled(true);
            jButton1.setText(l.s(L, 30));
            jButton1.setForeground(old);
            jPanel3.setBackground(old);
            SendFileName = "";
            SendFile = "";
            executorService.shutdown();

        }, 0, 1, TimeUnit.SECONDS);

    }

    public void kuldje() {

        sikereskodolas = false;
        sikereskuldes = false;
        kodoltzarva = false;
        File kulcsolando = new File(SendFileName);
        new Kodolas(Kulcs, kulcsolando, this, "kuld").run();
        if (sikereskodolas) {

            String kinek = jComboBox1.getSelectedItem().toString();
            int hol = kinek.indexOf(":");
            String ip = kinek.substring(hol + 1);

            int celport = Integer.parseInt((String) jComboBox3.getSelectedItem());
            int a = 0;
            while (!kodoltzarva) {
                a++;
                try {
                    sleep(1000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(FoForm.class.getName()).log(Level.SEVERE, null, ex);
                }
                if (a > 3) {
                    break;
                }
            }
            FelvetelKuldese hangkuldes = new FelvetelKuldese(SendFile, SendFileName, tray, kezdokulcs, this);
            if (hangkuldes.felvetelkuldese(ip, celport, 1)) {
                System.out.println(l.s(L, 31));
            } else {
                System.out.println(l.s(L, 32));
            }

        } else {
            System.out.println(l.s(L, 33));
        }
    }

    public void regisztraltak_keresese() {

        String valasz = "";
        try {
            valasz = new HttpCliens().sendPost(url, hash, "2", nick);
        } catch (Exception ex) {
            tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 6), l.s(L, 34), 0);
            System.out.println(l.s(L, 35) + ex);
        }
        byte[] decoded = Base64.decodeBase64(valasz);
        try {
            System.out.println(new String(decoded, "UTF-8") + "\n");
        } catch (UnsupportedEncodingException ex) {
            System.out.println(l.s(L, 36) + ex);
            tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 6), l.s(L, 37), 0);
            return;
        }
        try {
            valasz = new String(decoded, "UTF-8");
        } catch (UnsupportedEncodingException ex) {
            System.out.println(l.s(L, 36) + ex);
            tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 6), l.s(L, 37), 0);
            return;
        }
        String[] sorok;

        char someChar = '¤';
        int hanysorvan = 0;
        jComboBox1.removeAllItems();
        for (int i = 0; i < valasz.length(); i++) {
            if (valasz.charAt(i) == someChar) {
                hanysorvan++;
            }
        }
        if (hanysorvan == 1) {

            jComboBox1.addItem(valasz.substring(1, valasz.length()));

        } else {
            sorok = valasz.split("¤");

            jComboBox1.removeAllItems();
            for (int a = 1; a < sorok.length; a++) {
                jComboBox1.addItem(sorok[a]);

            }
        }

    }

    public void beregisztralva() {
        SzalLekapcsolasa = false;
        jButton3.setText(l.s(L, 12));
        jButton2.setEnabled(false);
        jPanel2.setBackground(Color.green);
        regisztraltak_keresese();
        Figyelo = new Thread(new FigyeloClass(this, tray, Integer.parseInt((String) jComboBox2.getSelectedItem())));
        Figyelo.start();
        jPSzerver.setBackground(Color.green);
        jComboBox2.setEnabled(false);

        Eletjel = new Thread(new EletjelClass(this, tray));
        Eletjel.start();
        jPFigyelo.setBackground(Color.green);

        FileFigyelo = new Thread(new FileFigyelo(this, tray, Integer.parseInt((String) jComboBox2.getSelectedItem()) + 1));
        FileFigyelo.start();

    }

    public void regtorlese() {
        SzalLekapcsolasa = true;
        jComboBox2.setEnabled(true);
        jButton2.setEnabled(true);
        Socket zaroSocket = null;
        DataOutputStream out = null;
        tray.uzenetek(this, tray.getTrayIcon(), l.s(L, 8), l.s(L, 38) + (String) jComboBox2.getSelectedItem(), 0);
        if (Figyelo.isAlive()) {

            System.out.println(l.s(L, 39));
        } else {
            System.out.println(l.s(L, 40));
        }
        if (Eletjel.isAlive()) {

            System.out.println(l.s(L, 41));
        } else {
            System.out.println(l.s(L, 42));
        }
        if (FileFigyelo.isAlive()) {

            System.out.println(l.s(L, 43));
        } else {
            System.out.println(l.s(L, 44));
        }
        try {
            zaroSocket = new Socket("localhost", Integer.parseInt((String) jComboBox2.getSelectedItem()));
        } catch (IOException ex) {
            hibavan_reset();
            tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 6), ex.toString(), 0);
        }
        if (Figyelo.isAlive()) {
            try {
                out = new DataOutputStream(zaroSocket.getOutputStream());
            } catch (IOException ex) {
                hibavan_reset();
                tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 6), ex.toString(), 0);
            }

            try {
                out.writeByte(1);
            } catch (IOException ex) {
                tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 6), ex.toString(), 0);
            }
            try {
                out.close();
            } catch (IOException ex) {
                tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 6), ex.toString(), 0);
            }
        }
        try {
            zaroSocket.close();
        } catch (IOException ex) {
            tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 6), ex.toString(), 0);
        }
        try {
            zaroSocket = new Socket("localhost", Integer.parseInt((String) jComboBox2.getSelectedItem()) + 1);
        } catch (IOException ex) {
            hibavan_reset();
            tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 6), ex.toString(), 0);
        }
        if (FileFigyelo.isAlive()) {
            try {
                out = new DataOutputStream(zaroSocket.getOutputStream());
            } catch (IOException ex) {
                hibavan_reset();
                tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 6), ex.toString(), 0);
            }

            try {
                out.writeByte(1);
            } catch (IOException ex) {
                tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 6), ex.toString(), 0);
            }
            try {
                out.close();
            } catch (IOException ex) {
                tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 6), ex.toString(), 0);
            }
        }
        try {
            zaroSocket.close();
        } catch (IOException ex) {
            tray.uzenetek_alert(this, tray.getTrayIcon(), l.s(L, 6), ex.toString(), 0);
        }
        jButton3.setText(l.s(L, 11));
        jPanel2.setBackground(Color.red);
        jButton3.setEnabled(false);

        jTextField1.setText("");
        iplist.clear();
        jComboBox1.removeAllItems();
        jPFigyelo.setBackground(Color.yellow);
        jPSzerver.setBackground(Color.yellow);

    }

    public void hibavan_reset() {
        jComboBox2.setEnabled(true);
        jButton2.setEnabled(true);
        jButton3.setText(l.s(L, 11));
        jPanel2.setBackground(Color.red);
        jButton3.setEnabled(false);

        jTextField1.setText("");
        iplist.clear();
        jComboBox1.removeAllItems();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FoForm.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FoForm.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FoForm.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FoForm.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        // build poup menu

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            for (String arg : args) {
                System.out.println("Language: " + arg);
                if ("en".equals(arg)) {
                    L = "en";
                } else {
                    L = "hu";
                }
            }
            new FoForm().setVisible(true);

        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    javax.swing.JButton JBText;
    javax.swing.JButton jButton1;
    javax.swing.JButton jButton2;
    javax.swing.JButton jButton3;
    javax.swing.JButton jButton4;
    javax.swing.JButton jButton5;
    javax.swing.JButton jButton6;
    javax.swing.JCheckBox jCheckBox1;
    javax.swing.JCheckBox jCheckBox2;
    javax.swing.JCheckBox jCheckBox3;
    javax.swing.JComboBox<String> jComboBox1;
    javax.swing.JComboBox<String> jComboBox2;
    javax.swing.JComboBox<String> jComboBox3;
    javax.swing.JComboBox<String> jComboBox4;
    javax.swing.JLabel jLabel1;
    javax.swing.JLabel jLabel10;
    javax.swing.JLabel jLabel11;
    javax.swing.JLabel jLabel12;
    javax.swing.JLabel jLabel13;
    javax.swing.JLabel jLabel14;
    javax.swing.JLabel jLabel15;
    javax.swing.JLabel jLabel16;
    javax.swing.JLabel jLabel2;
    javax.swing.JLabel jLabel3;
    javax.swing.JLabel jLabel4;
    javax.swing.JLabel jLabel5;
    javax.swing.JLabel jLabel6;
    javax.swing.JLabel jLabel7;
    javax.swing.JLabel jLabel8;
    javax.swing.JLabel jLabel9;
    javax.swing.JPanel jPFigyelo;
    javax.swing.JPanel jPSzerver;
    javax.swing.JPanel jPanel1;
    javax.swing.JPanel jPanel10;
    javax.swing.JPanel jPanel2;
    javax.swing.JPanel jPanel3;
    javax.swing.JPanel jPanel4;
    javax.swing.JPanel jPanel5;
    javax.swing.JPanel jPanel6;
    javax.swing.JPanel jPanel7;
    javax.swing.JPanel jPanel8;
    javax.swing.JPanel jPanel9;
    javax.swing.JProgressBar jProgressBar1;
    javax.swing.JScrollPane jScrollPane1;
    javax.swing.JSlider jSlider1;
    javax.swing.JSlider jSlider2;
    javax.swing.JTextField jTextField1;
    javax.swing.JTextPane jTextPane1;
    java.awt.List list1;
    // End of variables declaration//GEN-END:variables

    private void fajlkuldes() {
        final ScheduledExecutorService executorService2 = Executors.newSingleThreadScheduledExecutor();
        executorService2.scheduleAtFixedRate(() -> {
            File Kuldeni = new File(kuldottfile);
            long kuldottfilemerete = Kuldeni.length();
            if (Kulcs.length() < kuldottfilemerete && jCheckBox3.isSelected() == true) {

                tray.uzenetek_warning(this, tray.getTrayIcon(), l.s(L, 7), "A kulcsfájl kisebb a kódolandó állománynál, ha így akarja titkosítani, távolítsa el a Szigorúan One TimePad pipát, és kezdje "
                        + "újra a műveletet.", 1);
            } else {
                kodoltzarva = false;
                System.out.println("Fajlkuldes indul..");
                new Kodolas(Kulcs, Kuldeni, this, "fajlkuldes").run();
                if (sikeresfajlkodolas) {

                } else {
                    tray.uzenetek_warning(this, tray.getTrayIcon(), l.s(L, 7), "A fájl kódolása nem sikerült", 1);
                }

            }
            executorService2.shutdown();
        }, 0, 1, TimeUnit.SECONDS);
    }

}
