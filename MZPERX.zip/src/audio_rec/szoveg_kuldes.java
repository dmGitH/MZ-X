/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package audio_rec;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

/**
 *
 * @author dm
 */
public class szoveg_kuldes {

    Socket kuldoSocket = null;
    DataOutputStream out = null;
    DataInputStream in = null;

    long kezdokulcs;
    FoForm obj;
    byte[] kodszoveg;
    String ip;
    int port;
    
    static String L = "hu";
    LanguageClass l = new LanguageClass();

    public szoveg_kuldes(long kezdokulcs, FoForm obj, byte[] kodszoveg, String ip, int port) {
        this.kezdokulcs = kezdokulcs;
        this.obj = obj;
        this.kodszoveg = kodszoveg;
        this.ip = ip;
        this.port = port;
        L = FoForm.getL();
    }

   

    public boolean kapcsolodas_kuldes() {
        System.out.println("port: " + port);
        System.out.println("IP: " + ip);

        try {
            kuldoSocket = new Socket(ip, port);
            obj.tray.uzenetek(obj, obj.tray.getTrayIcon(), l.s(L,8), l.s(L,188), 0);
        } catch (IOException ex) {

            obj.tray.uzenetek_alert(obj, obj.tray.getTrayIcon(), l.s(L,6), l.s(L,189)+ex.toString(), 0);
            kuldolezar();
            return false;
        }

        try {
            out = new DataOutputStream(kuldoSocket.getOutputStream());
            
            obj.tray.uzenetek(obj, obj.tray.getTrayIcon(), l.s(L,8), l.s(L,190), 0);
        } catch (IOException ex) {

            obj.tray.uzenetek_alert(obj, obj.tray.getTrayIcon(), l.s(L,6), ex.toString(), 0);
            kuldolezar();
            return false;
        }
        try {
            in = new DataInputStream(kuldoSocket.getInputStream());
            obj.tray.uzenetek(obj, obj.tray.getTrayIcon(), l.s(L,8), l.s(L,191), 0);
        } catch (IOException ex) {

            obj.tray.uzenetek_alert(obj, obj.tray.getTrayIcon(), l.s(L,6), ex.toString(), 0);
            kuldolezar();
            return false;
        }

        try {
            out.writeByte(4);
        } catch (IOException ex) {
            kuldolezar();
            System.out.println(ex);
            return false;
        }
        byte kuldokapja;
        try {
            kuldokapja = in.readByte();

        } catch (IOException ex) {

            System.out.println(ex);
            kuldolezar();
            return false;
        }
        if (kuldokapja == 10) {
            System.out.println("sending ok start");

            try {
                out.writeLong(kezdokulcs);
            } catch (IOException ex) {
               obj.tray.uzenetek_alert(obj, obj.tray.getTrayIcon(), l.s(L,6), "--1 "+ex.toString(), 0);
               kuldolezar();
               return false;
            }
            
            try {
                out.writeInt(kodszoveg.length);
            } catch (IOException ex) {
                obj.tray.uzenetek_alert(obj, obj.tray.getTrayIcon(), l.s(L,6), "--2 "+ex.toString(), 0);
                kuldolezar();
                return false;
            }
            try {
                out.write(kodszoveg);
            } catch (IOException ex) {
                obj.tray.uzenetek_alert(obj, obj.tray.getTrayIcon(), l.s(L,6), "--2 "+ex.toString(), 0);
                kuldolezar();
                return false;
            }
            try {
                out.flush();
            } catch (IOException ex) {
                obj.tray.uzenetek_alert(obj, obj.tray.getTrayIcon(), l.s(L,6), "--3 "+ex.toString(), 0);
                kuldolezar();
                return false;
            }
        } else {
            System.out.println(l.s(L,192));
        }
        kuldolezar();
        return true;
    }

    public void kuldolezar() {
        try {
            in.close();
        } catch (IOException ex) {
            System.out.println(ex);
        }
        try {
            out.close();
        } catch (IOException ex) {
            System.out.println(ex);
        }
        try {
            kuldoSocket.close();
        } catch (IOException ex) {
            System.out.println(ex);
        }
        in = null;
        out = null;
        kuldoSocket = null;
    }
}
