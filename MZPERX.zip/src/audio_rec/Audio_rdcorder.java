/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package audio_rec;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import javax.sound.sampled.AudioFileFormat.Type;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.TargetDataLine;

public class Audio_rdcorder {

    static int FELVETEL_IDO = 10000;
    FoForm FoFormObj;
    static String L = "hu";
    LanguageClass l = new LanguageClass();

    public void setFoFormObj(FoForm FoFormObj) {
        this.FoFormObj = FoFormObj;
    }

    public boolean rogzit(int mennyit) {
         L=FoForm.getL();
        AudioFormat format = new AudioFormat(8000.0f, 16, 1, true, true);
        TargetDataLine microphone = null;
        AudioInputStream audioInputStream;
        SourceDataLine sourceDataLine = null;

        try {
            try {
                microphone = AudioSystem.getTargetDataLine(format);

                DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
                microphone = (TargetDataLine) AudioSystem.getLine(info);
                microphone.open(format);
            } catch (Exception e) {
                return false;
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            int numBytesRead;
            int CHUNK_SIZE = 1024;
            byte[] data = new byte[microphone.getBufferSize() / 5];
            microphone.start();

            int bytesRead = 0;

            try {
                while (bytesRead < FoFormObj.jSlider1.getValue() * FELVETEL_IDO) { // Just so I can test if recording
                    // my mic works...
                    numBytesRead = microphone.read(data, 0, CHUNK_SIZE);
                    bytesRead = bytesRead + numBytesRead;
//                    System.out.println(bytesRead);
                    out.write(data, 0, numBytesRead);

                }
                beepClass.tone(200, 500, FoFormObj.jSlider2.getValue());
            } catch (Exception e) {
                return false;
            }
            byte audioData[] = out.toByteArray();

            // Get an input stream on the byte array
            // containing the data
            InputStream byteArrayInputStream = new ByteArrayInputStream(
                    audioData);
            audioInputStream = new AudioInputStream(byteArrayInputStream, format, audioData.length / format.getFrameSize());
            DataLine.Info dataLineInfo = new DataLine.Info(SourceDataLine.class, format);
            sourceDataLine = (SourceDataLine) AudioSystem.getLine(dataLineInfo);
            sourceDataLine.open(format);
            sourceDataLine.start();
            FoFormObj.SendFileName = FoFormObj.jTextField1.getText()+"_"+new Adatbevitel().fajlnev() + ".wav";
            
            
            
            
         //   ------------------------befejezetlen a nyers adat fogadása rész   
//            long hossza = 0;
//            try {
//                hossza=audioInputStream.available();
//            } catch (IOException ex) {
//                Logger.getLogger(Audio_rdcorder.class.getName()).log(Level.SEVERE, null, ex);
//            }
//             int cnt;
//             byte[] wav=new byte[(int)hossza];
//            try {
//                while ((cnt = audioInputStream.read(wav, 0, wav.length)) != -1) {
//                    if (cnt > 0) {
//                        // Write data to the internal buffer of
//                        // the data line where it will be
//                        // delivered to the speaker.
//                        //sourceDataLine.write(wav, 0, cnt);
//                    }// end if
//                }
//            } catch (IOException ex) {
//                Logger.getLogger(Audio_rdcorder.class.getName()).log(Level.SEVERE, null, ex);
//            }
//            new NyersWavSec(FoFormObj.Kulcs,wav,FoFormObj).run();
//            
            
            try {
                AudioSystem.write(audioInputStream, Type.WAVE, new File(FoFormObj.SendFileName));
            } catch (IOException ex) {
                System.out.println(l.s(L,171) + ex);

                return false;
            }
            //byte tempBuffer[] = new byte[10000];
            //lejatszik(tempBuffer);
        } catch (LineUnavailableException e) {

            return false;
        }

        sourceDataLine.drain();
        sourceDataLine.close();
        microphone.close();
        return true;
    }

//    public void lejatszik(byte[] tempBuffer) {
//        int cnt = 0;
//
//        try {
//            while ((cnt = audioInputStream.read(tempBuffer, 0, tempBuffer.length)) != -1) {
//                if (cnt > 0) {
//                    // Write data to the internal buffer of
//                    // the data line where it will be
//                    // delivered to the speaker.
//                    sourceDataLine.write(tempBuffer, 0, cnt);
//                }// end if
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        // Block and wait for internal buffer of the
//        // data line to empty.
//        sourceDataLine.drain();
//        sourceDataLine.close();
//        microphone.close();
//
//    }
}
