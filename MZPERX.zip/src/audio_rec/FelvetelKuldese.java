/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package audio_rec;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dm
 */
public class FelvetelKuldese {

    Socket kuldoSocket = null;
    DataOutputStream out = null;
    DataInputStream kodoltfile = null;
    DataInputStream in = null;
    String SendFile;
    String SendFileName;
    TrayIconDemo tray;
    long kezdokulcs;
    FoForm obj;
    
    static String L = "hu";
    LanguageClass l = new LanguageClass();

    public FelvetelKuldese(String SendFile, String SendFileName, TrayIconDemo tray, long kezdokulcs, FoForm obj) {
        this.SendFile = SendFile;
        this.SendFileName = SendFileName;
        this.tray = tray;
        this.kezdokulcs = kezdokulcs;
        this.obj = obj;
        L=FoForm.getL();
        
    }

    public boolean felvetelkuldese(String ip, int celport, int miert) {
        
        System.out.println("port: " + celport);
        System.out.println("IP: " + ip);
        File sendfile = new File(SendFile);
        File filemerete = new File(SendFileName);
        System.out.println("File: " + sendfile.getName());

        try {
            kuldoSocket = new Socket(ip, celport);
        } catch (IOException ex) {

            tray.uzenetek_alert(obj, tray.getTrayIcon(), l.s(L,6), ex.toString(), 0);
            return false;
        }

        try {
            out = new DataOutputStream(kuldoSocket.getOutputStream());
        } catch (IOException ex) {

            tray.uzenetek_alert(obj, tray.getTrayIcon(), l.s(L,6), ex.toString(), 0);
            return false;
        }
        try {
            in = new DataInputStream(kuldoSocket.getInputStream());
        } catch (IOException ex) {

            tray.uzenetek_alert(obj, tray.getTrayIcon(), l.s(L,6), ex.toString(), 0);
            return false;
        }
        if (miert == 1) {
            try {
                out.writeByte(2);
            } catch (IOException ex) {

                System.out.println(ex);
                return false;
            }
        } else if (miert == 2) {
            try {
                out.writeByte(3);
            } catch (IOException ex) {

                System.out.println(ex);
                return false;
            }

        }
        byte kuldokapja;
        try {
            kuldokapja = in.readByte();

        } catch (IOException ex) {

            System.out.println(ex);
            return false;
        }
        if (kuldokapja == 10) {
            System.out.println(l.s(L,102));
            if (fajlnyitas()); else {
                return false;
            }
            long fajlmeret = filemerete.length();

            try {
                out.writeLong(kezdokulcs);
            } catch (IOException ex) {
                Logger.getLogger(FoForm.class.getName()).log(Level.SEVERE, null, ex);
            }

            System.out.println(l.s(L,103) + fajlmeret);
            int darabban;
            int buffmeret3 = 2048;

            if (fajlmeret / 2048 > 1) {

                try {
                    out.writeInt(buffmeret3);
                } catch (IOException ex) {
                    System.out.println(ex);
                }
                darabban = (int) fajlmeret / 2048;
//            out.writeInt(darabban);

            } else {
                buffmeret3 = (int) fajlmeret;
                try {
                    out.writeInt(buffmeret3);
                } catch (IOException ex) {
                    System.out.println(ex);
                }
                darabban = 1;
//             out.writeInt(darabban);
            }

            System.out.println(l.s(L,103) + fajlmeret);
            try {
                out.writeLong(fajlmeret); //fájlméret
            } catch (IOException ex) {
                System.out.println(ex);
            }
            try {
                out.writeUTF(sendfile.getName());//filename
            } catch (IOException ex) {
                System.out.println(ex);
            }
            try {
                out.flush();
            } catch (IOException ex) {
                System.out.println(ex);
            }
            //buff,darab,fajlmeret
            kodoltfile = null;
            if (fajlnyitas()); else {
                System.out.println(l.s(L,104));
                return false;
            }
            System.out.println(l.s(L,105) + SendFile);
            try {
                System.out.println(l.s(L,106) + kodoltfile.available());
            } catch (IOException ex) {
                Logger.getLogger(FoForm.class.getName()).log(Level.SEVERE, null, ex);
            }
            byte[] data = new byte[buffmeret3];
            try {
                while (kodoltfile.available() > buffmeret3) {
                    try {
                        kodoltfile.read(data);
                    } catch (IOException ex) {
                        System.out.println(ex);
                    }
                    try {
                        out.write(data);
                    } catch (IOException ex) {
                        System.out.println(ex);
                    }
                    try {
                        out.flush();
                    } catch (IOException ex) {
                        System.out.println(ex);
                    }
                    obj.kuldott+=buffmeret3;
                    final ScheduledExecutorService executorService2 = Executors.newSingleThreadScheduledExecutor();
                    executorService2.scheduleAtFixedRate(() -> {
                        obj.jLabel15.setText(l.s(L,112) + String.valueOf((obj.kuldott) / 1024/1024) + " MB");
                        executorService2.shutdown();
                    }, 0, 1, TimeUnit.SECONDS);
                }
            } catch (IOException ex) {
                Logger.getLogger(FoForm.class.getName()).log(Level.SEVERE, null, ex);
            }
            int ujbuffmeret = 0;
            try {
                ujbuffmeret = kodoltfile.available();
            } catch (IOException ex) {
                Logger.getLogger(FoForm.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println("new buffer lenght: " + ujbuffmeret);
            obj.kuldott+=buffmeret3;
            if (ujbuffmeret > 0) {
                data = new byte[ujbuffmeret];
                try {
                    kodoltfile.read(data);
                } catch (IOException ex) {
                    System.out.println(ex);
                }
                try {
                    out.write(data);
                } catch (IOException ex) {
                    System.out.println(ex);
                }

                try {
                    out.flush();
                } catch (IOException ex) {
                    System.out.println(ex);
                }
            }
            try {

                kodoltfile.close();
                kodoltfile = null;
                try {
                    try (DataOutputStream hozzair = new DataOutputStream(new FileOutputStream(SendFile, true))) {
                        hozzair.writeLong(kezdokulcs);
                    }
                } catch (FileNotFoundException ex) {
                    System.out.println(SendFile + l.s(L,107) + ex);

                }

            } catch (IOException ex) {
                System.out.println(ex);
            }
            String lezarva = "";
            try {
                lezarva = in.readUTF();
            } catch (IOException ex) {
                System.out.println(ex);
            }

            if ("OK".equals(lezarva)) {
                System.out.println("**OK**");
                kuldolezar();
            } else {
                System.out.println(l.s(L,110));
                kuldolezar();
                return false;
            }

        } else {
            tray.uzenetek_alert(obj, tray.getTrayIcon(), l.s(L,7), l.s(L,111), 1);
            return false;
        }

        return true;
    }

    public void kuldolezar() {
        try {
            in.close();
        } catch (IOException ex) {
            System.out.println(ex);
        }
        try {
            out.close();
        } catch (IOException ex) {
            System.out.println(ex);
        }
        try {
            kuldoSocket.close();
        } catch (IOException ex) {
            System.out.println(ex);
        }
        in = null;
        out = null;
        kuldoSocket = null;
    }

    public boolean fajlnyitas() {
        try {
            kodoltfile = new DataInputStream(new FileInputStream(SendFile));
            tray.uzenetek(obj, tray.getTrayIcon(), l.s(L,8), l.s(L,108) + SendFile, 0);
        } catch (FileNotFoundException ex) {
            System.out.println(SendFile + l.s(L,107) + ex);
            return false;

        }
        return true;
    }

}
