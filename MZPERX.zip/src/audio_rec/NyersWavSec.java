/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package audio_rec;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author dm használaton kívül, mert befejezetlen nem tesztel a nyer adat
 * kódolása és küldése , fogadása dekódolása..
 */
public class NyersWavSec implements Runnable {

    private final FoForm obj;
    byte[] kodolando;
    DataInputStream kulcscsomo;
    DataOutputStream kodolt;
    private final File Kulcs;
    private final byte[] Kulcsolando;
    String ujfilename = "";
    Adatbevitel ab;
    RandomAccessFile randomakulcs;
    boolean hiba = false;
    long kodolandohossza;
    String miert;
    long helyikezdokulcs;
    String eredetinev;

    static String L = "hu";
    LanguageClass l = new LanguageClass();

    public NyersWavSec(File Kulcs, byte[] Kulcsolando, FoForm obj) {
        this.Kulcs = Kulcs;
        this.Kulcsolando = Kulcsolando;
        this.obj = obj;
         L = FoForm.getL();

    }

    @Override
    public void run() {
       
        obj.sikereskodolas = start();

    }

    public boolean start() {

        System.out.println(l.s(L,80) + obj.kezdokulcs);
        System.out.println(l.s(L,80) + obj.kezdokulcs2);
        try {
            randomakulcs = new RandomAccessFile(Kulcs.getAbsolutePath(), "r");
//            obj.tray.uzenetek(obj, obj.tray.getTrayIcon(), "Info", " A Kulcsfájl megnyitva" + Kulcs.getAbsolutePath(), 0);
        } catch (FileNotFoundException ex) {
            System.out.println(l.s(L,76) + ex);
            obj.tray.uzenetek_alert(obj, obj.tray.getTrayIcon(), l.s(L,6), l.s(L,76) + ex, 0);
            obj.kodoltzarva = true;
            return false;
        }
        if ("kuld".equals(miert) || "fajlkuldes".equals(miert)) {
            obj.kezdokulcs = (long) (Kulcs.length() * Math.random());
            helyikezdokulcs = obj.kezdokulcs;
            System.out.println(l.s(L,80) + helyikezdokulcs);
            try {
                randomakulcs.seek(obj.kezdokulcs);
            } catch (IOException ex) {
                System.out.println(l.s(L,81) + ex);
                obj.tray.uzenetek_alert(obj, obj.tray.getTrayIcon(), l.s(L,6), l.s(L,81) + ex, 0);
                obj.kodoltzarva = true;
                return false;
            }
        } else {

            try {
                randomakulcs.seek(obj.kezdokulcs2);
            } catch (IOException ex) {
                System.out.println(l.s(L,81) + ex);
                obj.tray.uzenetek_alert(obj, obj.tray.getTrayIcon(), l.s(L,6), l.s(L,81) + ex, 0);
                obj.kodoltzarva = true;
                return false;
            }
        }

        kodolasfajlonkent(Kulcsolando);
        return !hiba;
    }

//    public void hangstreemkodolas(Data)
    public void kodolasfajlonkent(byte[] forras) {

        kodolando = forras;

        File kimenetifajl = null;
        if (null != miert) {
            switch (miert) {
                case "kuld":
                    kimenetifajl = new File(obj.jTextField1.getText() + "_" + new Adatbevitel().fajlnev() + ".wav" + ".sem");
                    obj.SendFile = obj.jTextField1.getText() + "_" + new Adatbevitel().fajlnev() + ".wav" + ".sem";
                    break;

                default:
                    break;
            }
        }

        try {
            kodolt = new DataOutputStream(new FileOutputStream(kimenetifajl));
            obj.tray.uzenetek(obj, obj.tray.getTrayIcon(), l.s(L,8), l.s(L,108) + kimenetifajl.getAbsolutePath(), 0);
        } catch (FileNotFoundException ex) {
            System.out.println(kimenetifajl.getName() + l.s(L,122) + ex);
            hiba = true;
            obj.kodoltzarva = true;
            return;
        }

        kodolasvezerles(0);
    }

    public void kodolasvezerles(long kodoltmennyiseg) {
        int pbtart = obj.jProgressBar1.getValue();
        if (pbtart > (int) (((kodoltmennyiseg) * 100.0f) / Kulcsolando.length)); else {
            obj.jProgressBar1.setValue((int) (((kodoltmennyiseg) * 100.0f) / Kulcsolando.length));

            obj.jLabel10.setText(l.s(L,145) + (int) (((kodoltmennyiseg) * 100.0f) / kodolandohossza) + "%");
        }
//        System.out.println("kodoltmennyiseg: "+kodoltmennyiseg+" eredetihossza: "+kodolandohossza);
        final ScheduledExecutorService executorService2 = Executors.newSingleThreadScheduledExecutor();
        executorService2.scheduleAtFixedRate(() -> {
            if ((kodoltmennyiseg == kodolandohossza)) {
                ab = new Adatbevitel();

                obj.tray.uzenetek(obj, obj.tray.getTrayIcon(),l.s(L,8), l.s(L,146) + ab.getCurrentTimeStamp(), 0);

                obj.jProgressBar1.setValue(0);

                try {
                    kodolt.close();
                    obj.tray.uzenetek(obj, obj.tray.getTrayIcon(), l.s(L,8), l.s(L,149), 0);
                    System.out.println(l.s(L,151));
                    obj.kodoltzarva = true;
                } catch (IOException ex) {
                    obj.tray.uzenetek_alert(obj, obj.tray.getTrayIcon(), l.s(L,6), l.s(L,150) + ex, 0);
                    obj.kodoltzarva = true;
                }
                if (null != miert) {
                    switch (miert) {
                        case "fogad": {
//                            MakeSound play = new MakeSound();
//                            play.playSound(Kulcsolando.getName() + ".wav");
//                            if ((Arrays.toString(obj.list1.getItems()).indexOf(Kulcsolando.getName()) == -1) || (obj.list1.getItems() == null)) {
//                                obj.list1.add(Kulcsolando.getName());
//                            }
//                            System.out.println("fogadnal: " + Kulcsolando.getAbsolutePath() + ".wav");
//                            File torli = new File(Kulcsolando.getAbsolutePath() + ".wav");
//                            new OriginDeleteSec(torli).run();
//                            break;
                        }
                        case "kuld": {
                            System.out.println("Kuldnél: " + obj.jTextField1.getText() + "_" + new Adatbevitel().fajlnev() + ".wav");
                            File torli = new File(obj.jTextField1.getText() + "_" + new Adatbevitel().fajlnev() + ".wav");
                            new OriginDeleteSec(torli).run();
                            break;
                        }
                        case "fajlkuldes": {

                            System.out.println(l.s(L,151));
                            String kinek = obj.jComboBox1.getSelectedItem().toString();
                            int hol = kinek.indexOf(":");
                            String ip = kinek.substring(hol + 1);
                            int celport = Integer.parseInt((String) obj.jComboBox3.getSelectedItem()) + 1;
                            AdataKuldese fajlkuldes = new AdataKuldese(eredetinev, eredetinev, obj.tray, helyikezdokulcs, obj);

                            if (fajlkuldes.felvetelkuldese(ip, celport, 2)) {
                                System.out.println(l.s(L,152));
                            } else {
                                System.out.println(l.s(L,153));
                            }
                            obj.kodoltzarva = true;
                            break;
                        }
                        case "fajlfogadas": {
                            System.out.println(l.s(L,154));
                            obj.kodoltzarva = true;
                            break;
                        }
                        default:
                            break;
                    }
                }
                obj.jProgressBar1.setValue(0);
                obj.jLabel10.setText("Művelet: ");

                try {
                    randomakulcs.close();
                    obj.tray.uzenetek(obj, obj.tray.getTrayIcon(), l.s(L,6), l.s(L,155), 0);
                } catch (IOException ex) {
                    obj.tray.uzenetek_alert(obj, obj.tray.getTrayIcon(), l.s(L,6), l.s(L,156) + ex, 0);
                }
                obj.jTextPane1.setCaretPosition(obj.jTextPane1.getDocument().getLength());
                executorService2.shutdown();
            } else {
                olvasas_kodolas_kiiras(kodoltmennyiseg);
                executorService2.shutdown();
            }
        }, 0, 1, TimeUnit.SECONDS);
    }

    public byte[] kulcsolvaso(int maradek) {
        byte[] kulcs = new byte[maradek];

        try {
            if (randomakulcs.getFilePointer() + maradek < Kulcs.length()) {
                try {
                    randomakulcs.read(kulcs);

                } catch (IOException ex) {
                    obj.tray.uzenetek_alert(obj, obj.tray.getTrayIcon(), l.s(L,6), l.s(L,157) + ex, 0);
                    hiba = true;
                    return kulcs;
                }
            } else {
                randomakulcs.seek(0);

                kulcsolvaso(maradek);
            }
        } catch (IOException ex) {
            obj.tray.uzenetek_alert(obj, obj.tray.getTrayIcon(), l.s(L,6), l.s(L,157) + ex, 0);
            hiba = true;
            return kulcs;
        }

        return kulcs;
    }

    public void olvasas_kodolas_kiiras(long kodoltmennyiseg) {
        byte[] kodolandochache;
        byte[] kulcs;
        byte[] kiirja;
        int maradek;

        if (kodoltmennyiseg + 1024 > Kulcsolando.length) {
            maradek = (int) (Kulcsolando.length - kodoltmennyiseg);
            kodolandochache = new byte[maradek];
            kiirja = new byte[maradek];
            kulcs = kulcsolvaso(maradek);
        } else {
            maradek = 1024;
            kodolandochache = new byte[maradek];
            kiirja = new byte[maradek];
            kulcs = kulcsolvaso(maradek);
        }

        for (int a = (int) kodoltmennyiseg; a < kodolandochache.length; a++) {
            kodolandochache[a - (int) kodoltmennyiseg] = Kulcsolando[a];
        }

        int i = 0;
        while (kodolandochache.length > i) {
            if (kulcs[i] == 0) {
                kulcs[i] = (byte) i;
            }
            kiirja[i] = (byte) (kodolandochache[i] ^ kulcs[i]);

            i++;

        }

        try {
            kodolt.write(kiirja);
        } catch (IOException ex) {
            obj.tray.uzenetek_alert(obj, obj.tray.getTrayIcon(), l.s(L,6), l.s(L,159) + ex, 0);
            hiba = true;
            return;
        }
        kodolasvezerles(kodoltmennyiseg + maradek);
    }
}
